import type { ReactNode } from "react";
import { cx } from "@/lib/utils";

export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="field-label">{label}</label>
      {children}
      {hint && <p className="mt-1.5 text-xs text-ink/40">{hint}</p>}
    </div>
  );
}

export function TextInput({
  name,
  defaultValue,
  placeholder,
  required,
}: {
  name: string;
  defaultValue?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <input
      name={name}
      defaultValue={defaultValue}
      placeholder={placeholder}
      required={required}
      className="field-input"
    />
  );
}

export function TextArea({
  name,
  defaultValue,
  placeholder,
  rows = 8,
  mono = true,
}: {
  name: string;
  defaultValue?: string;
  placeholder?: string;
  rows?: number;
  mono?: boolean;
}) {
  return (
    <textarea
      name={name}
      defaultValue={defaultValue}
      placeholder={placeholder}
      rows={rows}
      className={cx("field-textarea", !mono && "font-sans text-base")}
    />
  );
}

export function SelectInput({
  name,
  defaultValue,
  options,
}: {
  name: string;
  defaultValue?: string;
  options: string[];
}) {
  return (
    <select name={name} defaultValue={defaultValue} className="field-select">
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export function ColorInput({
  name,
  defaultValue = "#04aa6d",
}: {
  name: string;
  defaultValue?: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <input
        type="color"
        name={name}
        defaultValue={defaultValue}
        className="h-11 w-16 cursor-pointer rounded-xl border border-ink/10 bg-white p-1"
      />
      <span className="text-xs font-semibold text-ink/40">
        Brand color used across cards, buttons and highlights.
      </span>
    </div>
  );
}

export function PublishedToggle({
  defaultChecked = true,
}: {
  defaultChecked?: boolean;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-ink/10 bg-white px-4 py-3">
      <input
        type="checkbox"
        name="published"
        defaultChecked={defaultChecked}
        className="size-4.5 accent-[#04aa6d]"
      />
      <span>
        <span className="block text-sm font-bold">Published</span>
        <span className="text-xs text-ink/40">
          Visible on the public site when enabled.
        </span>
      </span>
    </label>
  );
}
