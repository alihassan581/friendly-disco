"use client";

import { useState } from "react";
import { ICON_CHOICES, getIcon } from "@/lib/icons";
import { cx } from "@/lib/utils";

export default function IconPicker({
  defaultValue = "Globe",
  color = "#04aa6d",
}: {
  defaultValue?: string;
  color?: string;
}) {
  const [value, setValue] = useState(defaultValue);

  return (
    <div>
      <input type="hidden" name="icon" value={value} />
      <div className="flex flex-wrap gap-2">
        {ICON_CHOICES.map((name) => {
          const Icon = getIcon(name);
          const active = value === name;
          return (
            <button
              key={name}
              type="button"
              onClick={() => setValue(name)}
              title={name}
              className={cx(
                "grid size-11 place-items-center rounded-xl border-2 transition-all",
                active
                  ? "border-forest bg-forest text-white shadow-lg"
                  : "border-ink/10 bg-white text-ink-soft hover:border-ink/30"
              )}
              style={active ? { boxShadow: `0 8px 24px -8px ${color}` } : undefined}
            >
              <Icon className="size-5" />
            </button>
          );
        })}
      </div>
    </div>
  );
}
