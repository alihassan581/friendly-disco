"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ArrowUpRight,
  BookOpen,
  GraduationCap,
  LayoutDashboard,
  Plus,
  Terminal,
} from "lucide-react";
import { cx } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard, exact: true },
  { href: "/dashboard/tutorials", label: "Tutorials", icon: BookOpen },
  { href: "/dashboard/courses", label: "Courses", icon: GraduationCap },
];

export default function DashboardNav() {
  const pathname = usePathname();

  const isActive = (href: string, exact?: boolean) =>
    exact ? pathname === href : pathname.startsWith(href);

  return (
    <aside className="sticky top-0 flex h-screen w-[230px] shrink-0 flex-col border-r border-white/10 bg-forest px-4 py-6 max-lg:hidden">
      <Link href="/dashboard" className="flex items-center gap-2.5 px-2">
        <span className="grid size-9 place-items-center rounded-xl bg-brand text-forest">
          <Terminal className="size-5" strokeWidth={2.5} />
        </span>
        <span className="font-display text-lg font-bold text-white">
          code<span className="text-brand">campus</span>
          <span className="block font-mono text-[10px] font-normal uppercase tracking-[0.2em] text-white/40">
            dashboard
          </span>
        </span>
      </Link>

      <p className="mt-8 px-2 text-[10px] font-bold uppercase tracking-[0.25em] text-white/35">
        Manage
      </p>
      <nav className="mt-2 grid gap-1">
        {NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cx(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors",
              isActive(item.href, item.exact)
                ? "bg-brand text-forest"
                : "text-white/70 hover:bg-white/10 hover:text-white"
            )}
          >
            <item.icon className="size-4.5" />
            {item.label}
          </Link>
        ))}
      </nav>

      <p className="mt-8 px-2 text-[10px] font-bold uppercase tracking-[0.25em] text-white/35">
        Create
      </p>
      <nav className="mt-2 grid gap-1">
        <Link
          href="/dashboard/tutorials/new"
          className={cx(
            "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors",
            pathname === "/dashboard/tutorials/new"
              ? "bg-white/15 text-white"
              : "text-white/70 hover:bg-white/10 hover:text-white"
          )}
        >
          <Plus className="size-4.5" />
          New tutorial
        </Link>
        <Link
          href="/dashboard/courses/new"
          className={cx(
            "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors",
            pathname === "/dashboard/courses/new"
              ? "bg-white/15 text-white"
              : "text-white/70 hover:bg-white/10 hover:text-white"
          )}
        >
          <Plus className="size-4.5" />
          New course
        </Link>
      </nav>

      <div className="mt-auto grid gap-1 border-t border-white/10 pt-4">
        <Link
          href="/"
          className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-white/70 transition-colors hover:bg-white/10 hover:text-white"
        >
          <ArrowUpRight className="size-4.5" />
          View live site
        </Link>
      </div>
    </aside>
  );
}
