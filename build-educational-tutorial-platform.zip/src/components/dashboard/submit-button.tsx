"use client";

import { useFormStatus } from "react-dom";
import { Loader2 } from "lucide-react";
import { cx } from "@/lib/utils";

export default function SubmitButton({
  children,
  variant = "primary",
  className,
}: {
  children: React.ReactNode;
  variant?: "primary" | "dark" | "ghost";
  className?: string;
}) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className={cx(
        "flex items-center justify-center gap-2 rounded-full px-6 py-2.5 text-sm font-bold transition-all disabled:cursor-not-allowed disabled:opacity-60",
        variant === "primary" &&
          "bg-brand text-forest hover:scale-[1.03] shadow-lg shadow-brand/25",
        variant === "dark" && "bg-forest text-white hover:bg-ink",
        variant === "ghost" &&
          "border border-ink/15 text-ink-soft hover:bg-cream",
        className
      )}
    >
      {pending && <Loader2 className="size-4 animate-spin" />}
      {children}
    </button>
  );
}
