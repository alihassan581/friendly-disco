"use client";

import { useTransition } from "react";
import { Loader2, Trash2 } from "lucide-react";
import { cx } from "@/lib/utils";

export default function DeleteButton({
  action,
  label,
  confirmMessage,
  iconOnly = false,
}: {
  action: () => Promise<void>;
  label?: string;
  confirmMessage?: string;
  iconOnly?: boolean;
}) {
  const [pending, startTransition] = useTransition();

  return (
    <button
      type="button"
      disabled={pending}
      onClick={() => {
        if (
          window.confirm(
            confirmMessage ??
              "Delete this item? This action cannot be undone."
          )
        ) {
          startTransition(async () => {
            await action();
          });
        }
      }}
      className={cx(
        "flex items-center justify-center gap-1.5 rounded-full text-xs font-bold transition-colors",
        iconOnly
          ? "size-8 border border-red-200 text-red-500 hover:bg-red-500 hover:text-white"
          : "border border-red-200 px-4 py-2 text-red-600 hover:bg-red-500 hover:text-white",
        pending && "opacity-60"
      )}
      title={label ?? "Delete"}
    >
      {pending ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        <Trash2 className="size-4" />
      )}
      {!iconOnly && (label ?? "Delete")}
    </button>
  );
}
