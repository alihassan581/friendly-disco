"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Search } from "lucide-react";

export default function HeroSearch() {
  const router = useRouter();
  const [query, setQuery] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        router.push(query.trim() ? `/tutorials?q=${encodeURIComponent(query)}` : "/tutorials");
      }}
      className="relative mx-auto w-full max-w-xl"
    >
      <Search className="pointer-events-none absolute left-5 top-1/2 size-5 -translate-y-1/2 text-ink/40" />
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search our tutorials, e.g. HTML"
        className="h-14 w-full rounded-full bg-white pl-13 pr-36 text-[15px] font-medium text-ink shadow-2xl shadow-black/30 outline-none ring-brand/50 transition-all placeholder:text-ink/40 focus:ring-4"
      />
      <button
        type="submit"
        className="absolute right-2 top-1/2 h-10 -translate-y-1/2 rounded-full bg-brand px-6 text-sm font-bold text-forest transition-transform hover:scale-105"
      >
        Search
      </button>
    </form>
  );
}
