"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { getIcon } from "@/lib/icons";

type Item = { slug: string; title: string; color: string; icon: string };

export default function MobileMenu({ tutorials }: { tutorials: Item[] }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="lg:hidden">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Toggle menu"
        className="grid size-10 place-items-center rounded-lg text-white transition-colors hover:bg-white/10"
      >
        {open ? <X className="size-5" /> : <Menu className="size-5" />}
      </button>

      {open && (
        <div className="absolute inset-x-0 top-16 max-h-[calc(100vh-4rem)] overflow-y-auto border-b border-white/10 bg-forest-soft p-4 shadow-2xl">
          <p className="px-2 pb-2 text-xs font-semibold uppercase tracking-widest text-white/40">
            Tutorials
          </p>
          <div className="grid gap-1">
            {tutorials.map((t) => {
              const Icon = getIcon(t.icon);
              return (
                <Link
                  key={t.slug}
                  href={`/tutorials/${t.slug}`}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-white/85 hover:bg-white/10"
                >
                  <span
                    className="grid size-7 place-items-center rounded-md"
                    style={{ backgroundColor: `${t.color}26`, color: t.color }}
                  >
                    <Icon className="size-4" />
                  </span>
                  {t.title}
                </Link>
              );
            })}
          </div>
          <div className="mt-4 grid gap-1 border-t border-white/10 pt-4">
            <Link
              href="/courses"
              onClick={() => setOpen(false)}
              className="rounded-xl px-3 py-2.5 text-sm font-semibold text-white hover:bg-white/10"
            >
              Courses
            </Link>
            <Link
              href="/tryit"
              onClick={() => setOpen(false)}
              className="rounded-xl px-3 py-2.5 text-sm font-semibold text-white hover:bg-white/10"
            >
              Code Editor
            </Link>
            <Link
              href="/dashboard"
              onClick={() => setOpen(false)}
              className="rounded-xl bg-brand px-3 py-2.5 text-center text-sm font-bold text-forest"
            >
              Go to Dashboard
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
