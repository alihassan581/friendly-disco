import Link from "next/link";
import { AtSign, MessagesSquare, Rss, Share2, Terminal } from "lucide-react";
import { getPublishedTutorials } from "@/lib/queries";

export default async function SiteFooter() {
  const tutorials = await getPublishedTutorials();

  return (
    <footer className="bg-forest text-white/70">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Link href="/" className="flex items-center gap-2.5">
              <span className="grid size-9 place-items-center rounded-xl bg-brand text-forest">
                <Terminal className="size-5" strokeWidth={2.5} />
              </span>
              <span className="font-display text-xl font-bold text-white">
                code<span className="text-brand">campus</span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed">
              Free interactive tutorials and courses for learning web
              development — from your first tag to shipping full apps.
            </p>
            <div className="mt-6 flex gap-2">
              {[MessagesSquare, Share2, Rss, AtSign].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="grid size-9 place-items-center rounded-lg bg-white/10 transition-colors hover:bg-brand hover:text-forest"
                >
                  <Icon className="size-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-widest text-white">
              Tutorials
            </h4>
            <ul className="mt-4 grid gap-2 text-sm">
              {tutorials.slice(0, 6).map((t) => (
                <li key={t.id}>
                  <Link
                    href={`/tutorials/${t.slug}`}
                    className="transition-colors hover:text-brand"
                  >
                    Learn {t.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-widest text-white">
              Learning
            </h4>
            <ul className="mt-4 grid gap-2 text-sm">
              <li>
                <Link href="/courses" className="transition-colors hover:text-brand">
                  All courses
                </Link>
              </li>
              <li>
                <Link href="/tryit" className="transition-colors hover:text-brand">
                  Code editor
                </Link>
              </li>
              <li>
                <Link href="/tutorials" className="transition-colors hover:text-brand">
                  Tutorial index
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-widest text-white">
              Platform
            </h4>
            <ul className="mt-4 grid gap-2 text-sm">
              <li>
                <Link href="/dashboard" className="transition-colors hover:text-brand">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link
                  href="/dashboard/tutorials/new"
                  className="transition-colors hover:text-brand"
                >
                  Upload a tutorial
                </Link>
              </li>
              <li>
                <Link
                  href="/dashboard/courses/new"
                  className="transition-colors hover:text-brand"
                >
                  Upload a course
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 text-xs sm:flex-row">
          <p>© {new Date().getFullYear()} Codecampus. Learning never stops.</p>
          <p className="font-mono text-white/40">
            Built with Next.js, Drizzle &amp; PostgreSQL
          </p>
        </div>
      </div>
    </footer>
  );
}
