import Link from "next/link";
import { Home } from "lucide-react";
import type { Tutorial, TutorialSection } from "@/db/schema";
import { cx } from "@/lib/utils";

export default function TutorialSidebar({
  tutorial,
  sections,
  activeId,
}: {
  tutorial: Tutorial;
  sections: TutorialSection[];
  activeId?: number;
}) {
  const activeIndex = sections.findIndex((s) => s.id === activeId);

  return (
    <div className="flex h-full flex-col">
      <Link
        href={`/tutorials/${tutorial.slug}`}
        className="mb-3 flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-bold transition-colors hover:bg-cream"
      >
        <Home className="size-4" style={{ color: tutorial.color }} />
        {tutorial.title} HOME
      </Link>

      <div className="mb-3 px-3">
        <div className="h-1.5 overflow-hidden rounded-full bg-cream">
          <div
            className="h-full rounded-full transition-all"
            style={{
              backgroundColor: tutorial.color,
              width: `${
                activeIndex >= 0
                  ? Math.round(((activeIndex + 1) / Math.max(sections.length, 1)) * 100)
                  : 0
              }%`,
            }}
          />
        </div>
        <p className="mt-2 text-[11px] font-bold uppercase tracking-widest text-ink/35">
          {activeIndex >= 0
            ? `Lesson ${activeIndex + 1} of ${sections.length}`
            : `${sections.length} lessons`}
        </p>
      </div>

      <nav className="flex-1 space-y-0.5 overflow-y-auto pr-1">
        {sections.map((s, i) => {
          const active = s.id === activeId;
          return (
            <Link
              key={s.id}
              href={`/tutorials/${tutorial.slug}/${s.slug}`}
              className={cx(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors",
                active
                  ? "font-bold text-white"
                  : "font-medium text-ink-soft hover:bg-cream hover:text-ink"
              )}
              style={active ? { backgroundColor: tutorial.color } : undefined}
            >
              <span
                className={cx(
                  "font-mono text-[11px]",
                  active ? "text-white/70" : "text-ink/30"
                )}
              >
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="truncate">{s.title}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
