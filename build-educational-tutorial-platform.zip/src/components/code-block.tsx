import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { highlightCode } from "@/lib/highlight";
import CopyButton from "@/components/copy-button";

export default function CodeBlock({
  code,
  lang,
  runnableSectionId,
  label = "Example",
}: {
  code: string;
  lang?: string;
  runnableSectionId?: number | null;
  label?: string;
}) {
  const html = highlightCode(code, lang);
  const runnable = runnableSectionId != null && lang !== "sql" && lang !== "text";

  return (
    <figure className="code-shell my-7 shadow-xl shadow-ink/10 ring-1 ring-black/10">
      <figcaption className="flex items-center gap-3 border-b border-white/10 bg-[#21252b] px-4 py-2.5">
        <span className="flex gap-1.5">
          <span className="size-3 rounded-full bg-[#ff5f57]" />
          <span className="size-3 rounded-full bg-[#febc2e]" />
          <span className="size-3 rounded-full bg-[#28c840]" />
        </span>
        <span className="text-xs font-semibold uppercase tracking-widest text-white/50">
          {label}
        </span>
        <span className="ml-auto flex items-center gap-2">
          <CopyButton code={code} />
          {runnable && (
            <Link
              href={`/tryit/${runnableSectionId}`}
              target="_blank"
              className="flex items-center gap-1.5 rounded-full bg-brand px-3.5 py-1.5 text-xs font-bold text-forest transition-colors hover:bg-white"
            >
              Try it Yourself
              <ArrowUpRight className="size-3.5" />
            </Link>
          )}
        </span>
      </figcaption>
      <pre className="code-pre" dangerouslySetInnerHTML={{ __html: html }} />
    </figure>
  );
}
