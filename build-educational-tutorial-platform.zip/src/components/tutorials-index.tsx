"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowRight, Search, SearchX } from "lucide-react";
import { getIcon } from "@/lib/icons";
import { cx } from "@/lib/utils";

type TutorialItem = {
  id: number;
  slug: string;
  title: string;
  tagline: string;
  category: string;
  color: string;
  icon: string;
  lessons: number;
};

export default function TutorialsIndex({
  tutorials,
  initialQuery,
}: {
  tutorials: TutorialItem[];
  initialQuery: string;
}) {
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState("All");

  const categories = useMemo(
    () => ["All", ...Array.from(new Set(tutorials.map((t) => t.category)))],
    [tutorials]
  );

  const filtered = tutorials.filter((t) => {
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q ||
      t.title.toLowerCase().includes(q) ||
      t.tagline.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q);
    const matchesCategory = category === "All" || t.category === category;
    return matchesQuery && matchesCategory;
  });

  return (
    <div>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
        <div className="relative w-full max-w-md">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-4.5 -translate-y-1/2 text-ink/35" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter tutorials…"
            className="field-input h-12 rounded-full pl-11"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cx(
                "rounded-full px-4 py-2 text-xs font-bold uppercase tracking-wider transition-colors",
                category === c
                  ? "bg-forest text-white"
                  : "bg-cream text-ink-soft hover:bg-mist"
              )}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="mt-16 grid place-items-center rounded-3xl border border-dashed border-ink/20 py-20 text-center">
          <SearchX className="size-10 text-ink/25" />
          <p className="mt-4 font-display text-xl font-bold">
            No tutorials found
          </p>
          <p className="mt-1 text-sm text-ink-soft">
            Try a different keyword — or upload one from the dashboard.
          </p>
        </div>
      ) : (
        <div className="mt-8 grid gap-4">
          {filtered.map((t, i) => {
            const Icon = getIcon(t.icon);
            return (
              <Link
                key={t.id}
                href={`/tutorials/${t.slug}`}
                className="card-lift group flex items-center gap-5 rounded-2xl border border-ink/10 bg-white p-5 shadow-sm hover:shadow-xl hover:shadow-ink/10 sm:p-6"
              >
                <span className="hidden font-mono text-sm font-bold text-ink/25 sm:block">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span
                  className="grid size-13 shrink-0 place-items-center rounded-2xl"
                  style={{ backgroundColor: `${t.color}1c`, color: t.color }}
                >
                  <Icon className="size-6.5" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-3">
                    <span className="truncate font-display text-xl font-bold tracking-tight">
                      {t.title}
                    </span>
                    <span className="hidden rounded-full bg-cream px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider text-ink-soft sm:block">
                      {t.category}
                    </span>
                  </span>
                  <span className="mt-0.5 block truncate text-sm text-ink-soft">
                    {t.tagline}
                  </span>
                </span>
                <span className="hidden text-xs font-bold text-ink/40 md:block">
                  {t.lessons} lessons
                </span>
                <span
                  className="grid size-10 shrink-0 place-items-center rounded-full text-white transition-transform duration-300 group-hover:scale-110"
                  style={{ backgroundColor: t.color }}
                >
                  <ArrowRight className="size-4.5" />
                </span>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
