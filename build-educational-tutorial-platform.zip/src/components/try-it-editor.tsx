"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { html } from "@codemirror/lang-html";
import { Play, RotateCcw } from "lucide-react";

const CodeMirror = dynamic(() => import("@uiw/react-codemirror"), {
  ssr: false,
  loading: () => (
    <div className="grid h-full min-h-[320px] place-items-center bg-[#0d1117] text-sm text-white/40">
      Loading editor…
    </div>
  ),
});

export default function TryItEditor({
  initialCode,
  height = 560,
  compact = false,
}: {
  initialCode: string;
  height?: number;
  compact?: boolean;
}) {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState(initialCode);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setCode(initialCode);
    setOutput(initialCode);
  }, [initialCode]);

  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setOutput(code), 900);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [code]);

  const extensions = useMemo(
    () => [html({ matchClosingTags: true, autoCloseTags: true })],
    []
  );

  return (
    <div
      className="overflow-hidden rounded-2xl bg-[#0d1117] shadow-2xl ring-1 ring-black/20"
      style={{ boxShadow: "0 24px 80px -24px rgba(10,31,20,0.55)" }}
    >
      {/* toolbar */}
      <div className="flex items-center gap-2 border-b border-white/10 bg-[#161d27] px-3 py-2">
        <span className="flex gap-1.5 pl-1">
          <span className="size-3 rounded-full bg-[#ff5f57]" />
          <span className="size-3 rounded-full bg-[#febc2e]" />
          <span className="size-3 rounded-full bg-[#28c840]" />
        </span>
        <span className="rounded-md bg-white/5 px-2.5 py-1 font-mono text-xs text-white/60">
          index.html
        </span>
        <span className="ml-auto flex items-center gap-2">
          <button
            onClick={() => setCode(initialCode)}
            className="flex items-center gap-1.5 rounded-full border border-white/15 px-3 py-1.5 text-xs font-semibold text-white/70 transition-colors hover:bg-white/10 hover:text-white"
          >
            <RotateCcw className="size-3.5" />
            Reset
          </button>
          <button
            onClick={() => setOutput(code)}
            className="flex items-center gap-1.5 rounded-full bg-brand px-4 py-1.5 text-xs font-bold text-forest transition-transform hover:scale-105"
          >
            <Play className="size-3.5" strokeWidth={2.5} />
            Run
          </button>
        </span>
      </div>

      <div className="grid lg:grid-cols-2">
        {/* editor */}
        <div
          className="border-b border-white/10 lg:border-b-0 lg:border-r"
          style={{ height: compact ? "auto" : height }}
        >
          <CodeMirror
            value={code}
            onChange={setCode}
            extensions={extensions}
            theme="dark"
            height={compact ? "100%" : `${height}px`}
            style={{
              fontSize: 14,
              height: "100%",
              backgroundColor: "#0d1117",
            }}
            basicSetup={{
              lineNumbers: true,
              foldGutter: false,
              highlightActiveLine: true,
              highlightActiveLineGutter: false,
              autocompletion: true,
            }}
          />
        </div>

        {/* result */}
        <div className="flex flex-col bg-white" style={{ height }}>
          <div className="border-b border-ink/10 bg-paper px-4 py-2 text-xs font-semibold uppercase tracking-widest text-ink-soft">
            Result
          </div>
          <iframe
            title="Code result"
            srcDoc={output}
            sandbox="allow-scripts allow-modals"
            className="w-full flex-1 bg-white"
          />
        </div>
      </div>
    </div>
  );
}
