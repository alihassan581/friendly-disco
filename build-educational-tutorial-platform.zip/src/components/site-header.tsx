import Link from "next/link";
import { ChevronDown, LayoutDashboard, Play, Terminal } from "lucide-react";
import { getPublishedTutorials } from "@/lib/queries";
import { getIcon } from "@/lib/icons";
import MobileMenu from "@/components/mobile-menu";

export default async function SiteHeader() {
  const tutorials = await getPublishedTutorials();

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-forest/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <Link href="/" className="group flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-xl bg-brand text-forest shadow-[0_0_24px_rgba(4,170,109,0.45)] transition-transform duration-300 group-hover:rotate-6">
            <Terminal className="size-5" strokeWidth={2.5} />
          </span>
          <span className="font-display text-xl font-bold tracking-tight text-white">
            code<span className="text-brand">campus</span>
          </span>
        </Link>

        <nav className="ml-6 hidden items-center gap-1 lg:flex">
          <div className="group relative">
            <button className="flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white">
              Tutorials
              <ChevronDown className="size-4 transition-transform duration-300 group-hover:rotate-180" />
            </button>
            <div className="invisible absolute left-0 top-full pt-2 opacity-0 transition-all duration-200 group-hover:visible group-hover:opacity-100">
              <div className="w-[34rem] rounded-2xl border border-white/10 bg-forest-soft p-3 shadow-2xl shadow-black/40">
                <div className="grid grid-cols-2 gap-1">
                  {tutorials.map((t) => {
                    const Icon = getIcon(t.icon);
                    return (
                      <Link
                        key={t.id}
                        href={`/tutorials/${t.slug}`}
                        className="flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors hover:bg-white/10"
                      >
                        <span
                          className="grid size-8 shrink-0 place-items-center rounded-lg"
                          style={{ backgroundColor: `${t.color}26`, color: t.color }}
                        >
                          <Icon className="size-4" />
                        </span>
                        <span>
                          <span className="block text-sm font-semibold text-white">
                            {t.title}
                          </span>
                          <span className="block text-xs text-white/50">
                            {t.tagline || `Learn ${t.title}`}
                          </span>
                        </span>
                      </Link>
                    );
                  })}
                </div>
                <Link
                  href="/tutorials"
                  className="mt-2 block rounded-xl bg-brand/15 px-3 py-2.5 text-center text-sm font-semibold text-brand transition-colors hover:bg-brand/25"
                >
                  Browse all tutorials
                </Link>
              </div>
            </div>
          </div>

          <Link
            href="/courses"
            className="rounded-lg px-3.5 py-2 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white"
          >
            Courses
          </Link>
          <Link
            href="/tryit"
            className="flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white"
          >
            <Play className="size-3.5" />
            Code Editor
          </Link>
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <Link
            href="/dashboard"
            className="hidden items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-brand hover:text-forest sm:flex"
          >
            <LayoutDashboard className="size-4" />
            Dashboard
          </Link>
          <MobileMenu
            tutorials={tutorials.map((t) => ({
              slug: t.slug,
              title: t.title,
              color: t.color,
              icon: t.icon,
            }))}
          />
        </div>
      </div>
    </header>
  );
}
