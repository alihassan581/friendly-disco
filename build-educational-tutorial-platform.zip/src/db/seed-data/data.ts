import type { TutorialDef } from "./front";

export const sqlTutorial: TutorialDef = {
  tutorial: {
    title: "SQL",
    slug: "sql",
    tagline: "The language for managing databases",
    description:
      "SQL lets you store, query and manage data in relational databases — the backbone of almost every application. Learn SELECT, filtering, sorting and JOINs, the commands every developer uses daily.",
    category: "Databases",
    color: "#e38c00",
    icon: "Database",
  },
  sections: [
    {
      title: "SQL Introduction",
      content: `
<h2>What is SQL?</h2>
<ul>
<li>SQL stands for <strong>Structured Query Language</strong></li>
<li>It is used to communicate with relational databases: PostgreSQL, MySQL, SQLite, SQL Server</li>
<li>With SQL you can <strong>insert, read, update and delete</strong> data (the famous CRUD)</li>
</ul>
<h2>Databases are made of tables</h2>
<p>A table stores records in rows and columns. A <code>Customers</code> table might have columns like <code>id</code>, <code>name</code>, <code>city</code> and <code>country</code>. Each row is one customer.</p>
<h2>SQL keywords are not case sensitive</h2>
<p><code>select</code> and <code>SELECT</code> are identical. Uppercase keywords are a widespread convention that makes statements easier to scan — we use it throughout this tutorial.</p>
<div class="note-box"><strong>Note</strong>Codecampus itself runs on PostgreSQL and Drizzle ORM — everything you learn here applies directly to real apps.</div>`,
      codeExample: `-- A look at the Customers table
SELECT id, name, city, country
FROM Customers;

-- id | name         | city      | country
-- 1  | Ada Lovelace | London    | UK
-- 2  | Grace Hopper | New York  | USA
-- 3  | Alan Turing  | London    | UK`,
    },
    {
      title: "SQL SELECT",
      content: `
<h2>The command you will type most</h2>
<p><code>SELECT</code> retrieves data from a table. Choose the columns you need, or use <code>*</code> to grab everything:</p>
<p><code>SELECT name, city FROM Customers;</code></p>
<h2>SELECT DISTINCT</h2>
<p>Tables often contain duplicate values in a column — many customers share the same city. <code>SELECT DISTINCT country FROM Customers;</code> returns each country only once.</p>
<h2>Column aliases</h2>
<p>Rename an output column with <code>AS</code>: <code>SELECT name AS customer_name FROM Customers;</code> — useful for reports and when combining columns.</p>`,
      codeExample: `-- Pick two columns from the table
SELECT name, country
FROM Customers;

-- Each country only once
SELECT DISTINCT country
FROM Customers;

-- Rename the output column
SELECT name AS customer_name
FROM Customers;`,
    },
    {
      title: "SQL WHERE",
      content: `
<h2>Filter rows with conditions</h2>
<p>The <code>WHERE</code> clause keeps only rows that match a condition:</p>
<p><code>SELECT * FROM Customers WHERE country = 'UK';</code></p>
<h2>Operators for filtering</h2>
<table>
<tr><th>Operator</th><th>Meaning</th></tr>
<tr><td>=</td><td>Equal</td></tr>
<tr><td>&gt; / &lt;</td><td>Greater / less than</td></tr>
<tr><td>BETWEEN</td><td>Within a range</td></tr>
<tr><td>LIKE</td><td>Pattern match, % is a wildcard</td></tr>
<tr><td>IN</td><td>Match any value in a list</td></tr>
<tr><td>AND / OR / NOT</td><td>Combine conditions</td></tr>
</table>
<div class="tip-box"><strong>Tip</strong>Text values in SQL use <strong>single quotes</strong>: <code>WHERE city = 'London'</code>. Numbers need no quotes.</div>`,
      codeExample: `-- Customers from a specific country
SELECT * FROM Customers
WHERE country = 'UK';

-- Names starting with the letter A
SELECT * FROM Customers
WHERE name LIKE 'A%';

-- Combine conditions
SELECT * FROM Customers
WHERE country = 'UK' AND city = 'London';

-- Match any value from a list
SELECT * FROM Customers
WHERE country IN ('UK', 'USA', 'Japan');`,
    },
    {
      title: "SQL ORDER BY",
      content: `
<h2>Sort the results</h2>
<p><code>ORDER BY</code> sorts rows by one or more columns, ascending by default (<code>ASC</code>). Add <code>DESC</code> for descending order:</p>
<p><code>SELECT * FROM Products ORDER BY price DESC;</code></p>
<h2>Sort by several columns</h2>
<p>Multiple columns form a tie-breaker chain — first by country A→Z, then by name within each country:</p>
<p><code>SELECT * FROM Customers ORDER BY country, name;</code></p>
<div class="note-box"><strong>Note</strong>Without ORDER BY, the database makes no promises about row order. If order matters, always sort explicitly.</div>`,
      codeExample: `-- Cheapest products first
SELECT name, price
FROM Products
ORDER BY price ASC;

-- Most expensive first
SELECT name, price
FROM Products
ORDER BY price DESC;

-- Country A to Z, then name A to Z inside it
SELECT name, country
FROM Customers
ORDER BY country, name;`,
    },
    {
      title: "SQL JOIN",
      content: `
<h2>Combine tables</h2>
<p>Real applications spread data across many tables. A <code>JOIN</code> stitches related rows together using a shared column — for example <code>Orders.customer_id</code> matching <code>Customers.id</code>.</p>
<h2>The join family</h2>
<ul>
<li><strong>(INNER) JOIN</strong> — only rows with a match in both tables</li>
<li><strong>LEFT JOIN</strong> — all rows from the left table, plus matches (or NULL) from the right</li>
<li><strong>RIGHT JOIN</strong> — the mirror image of LEFT JOIN</li>
<li><strong>FULL OUTER JOIN</strong> — everything from both sides</li>
</ul>
<h2>Qualified column names</h2>
<p>When both tables share a column name, prefix it with the table name — <code>Customers.id</code> — or add short aliases like <code>FROM Customers c JOIN Orders o</code>.</p>`,
      codeExample: `-- Orders together with the customer who placed them
SELECT o.id AS order_id, c.name, o.total
FROM Orders o
INNER JOIN Customers c ON o.customer_id = c.id
ORDER BY o.id;

-- Every customer, even those with no orders yet
SELECT c.name, o.id AS order_id
FROM Customers c
LEFT JOIN Orders o ON o.customer_id = c.id;`,
    },
  ],
};

export const reactTutorial: TutorialDef = {
  tutorial: {
    title: "React",
    slug: "react",
    tagline: "The library for building user interfaces",
    description:
      "React powers the interfaces of the world's biggest apps. Learn components, JSX, props, state and hooks — the mental model behind modern frontend development, including this very site.",
    category: "Web Development",
    color: "#00c2d8",
    icon: "Atom",
  },
  sections: [
    {
      title: "React Introduction",
      content: `
<h2>What is React?</h2>
<p>React is a JavaScript library for building user interfaces out of <strong>components</strong> — small, reusable pieces that describe what the UI should look like for any given data. Change the data, and React efficiently updates only what changed.</p>
<h2>Why developers love it</h2>
<ul>
<li><strong>Declarative</strong> — describe the result, React handles the DOM updates</li>
<li><strong>Component-based</strong> — build complex UIs from simple, testable pieces</li>
<li><strong>Learn once</strong> — the same model powers web (React DOM), native apps (React Native) and full-stack frameworks like Next.js</li>
</ul>
<h2>React in the real world</h2>
<p>Meta, Netflix, Airbnb and countless startups build with React. This learning platform is built with React Server Components and Next.js.</p>
<div class="tip-box"><strong>Tip</strong>Finish the JavaScript tutorial first — functions, arrays and objects are the daily vocabulary of React.</div>`,
      codeExample: `// A React component is just a function
// that returns what should appear on screen.

function Welcome() {
  return (
    <h1 className="title">
      Hello from my first component!
    </h1>
  );
}

// Rendered inside an app, it displays
// an h1 with that text — no DOM calls needed.`,
    },
    {
      title: "React JSX",
      content: `
<h2>HTML inside JavaScript</h2>
<p>JSX is a syntax extension that lets you write markup right inside your JavaScript. It looks like HTML but has full JavaScript power behind it.</p>
<h2>Rules of JSX</h2>
<ul>
<li>Return <strong>one</strong> root element — wrap multiples in a single parent or a fragment <code>&lt;&gt;&lt;/&gt;</code></li>
<li>Use <code>className</code> instead of <code>class</code> (class is a reserved word in JS)</li>
<li>Embed any expression with curly braces: <code>&lt;p&gt;{2 + 2}&lt;/p&gt;</code> renders <code>4</code></li>
<li>Every tag must be closed — even <code>&lt;img /&gt;</code></li>
</ul>
<div class="note-box"><strong>Note</strong>JSX is not required by React, but almost everyone uses it — it keeps UI and logic in one readable place.</div>`,
      codeExample: `function Profile() {
  const learner = "Ada";
  const streak = 12;
  const topics = ["HTML", "CSS", "React"];

  // Curly braces embed any JavaScript expression
  return (
    <div className="profile">
      <h2>{learner}'s dashboard</h2>
      <p>Day streak: {streak} days</p>
      <p>Next up: {topics[2]}</p>
      <p>Courses finished: {streak > 10 ? "Several!" : "Just starting"}</p>
    </div>
  );
}`,
    },
    {
      title: "React Components",
      content: `
<h2>Lego bricks for interfaces</h2>
<p>Components are independent, reusable functions. A button, a card, a navbar — each is a component you define once and use everywhere. Component names <strong>must start with a capital letter</strong>, or React treats them as plain HTML tags.</p>
<h2>Composing components</h2>
<p>Components nest inside each other to form trees. A <code>Page</code> contains a <code>Header</code>, which contains a <code>Logo</code> — each piece focused on one job.</p>
<h2>Props: passing data down</h2>
<p>Components receive inputs called <strong>props</strong> (short for properties) — read-only values from the parent, arriving as a single object argument.</p>`,
      codeExample: `// A small reusable component with props
function Badge({ label, color }) {
  return (
    <span style={{ background: color }}>
      {label}
    </span>
  );
}

// Composed inside a bigger component
function LessonCard() {
  return (
    <article>
      <Badge label="New" color="#04aa6d" />
      <h3>React Components</h3>
      <p>Lesson 3 of 5</p>
    </article>
  );
}

// And inside the page — reuse with different props
function Page() {
  return (
    <main>
      <LessonCard />
      <Badge label="Pro" color="#3b82f6" />
    </main>
  );
}`,
    },
    {
      title: "React Props",
      content: `
<h2>Configure your components</h2>
<p>Props make components configurable: the same <code>&lt;Button&gt;</code> can render as "Save", "Delete" or "Enroll" depending on the props you pass. Think of props like function arguments.</p>
<h2>Destructuring props</h2>
<p>Most codebases unpack props directly in the signature: <code>function Card({ title, price })</code>. Defaults come along: <code>{ price = "Free" }</code>.</p>
<h2>The children prop</h2>
<p>Anything placed between a component's opening and closing tags arrives as <code>children</code> — the secret behind layout wrappers like <code>&lt;Card&gt;anything here&lt;/Card&gt;</code>.</p>
<div class="tip-box"><strong>Tip</strong>Props flow one way: parent to child. To change a parent, children call functions passed down as props.</div>`,
      codeExample: `function CourseCard({ title, price = "Free", children }) {
  return (
    <div className="card">
      <h3>{title}</h3>
      <p className="price">{price}</p>
      {/* anything nested between the tags lands here */}
      {children}
    </div>
  );
}

function Catalogue() {
  return (
    <>
      <CourseCard title="Frontend Foundations">
        <button>Enroll now</button>
      </CourseCard>

      <CourseCard title="JavaScript Mastery" price="$49">
        <button>Add to cart</button>
      </CourseCard>
    </>
  );
}`,
    },
    {
      title: "React State & Hooks",
      content: `
<h2>Components that remember</h2>
<p>State is data a component owns and updates over time — a counter, an open menu, form text. When state changes, React re-renders the component with the new value. State is created with the <code>useState</code> <strong>hook</strong>:</p>
<p><code>const [count, setCount] = useState(0);</code></p>
<h2>Rules of hooks</h2>
<ul>
<li>Call hooks only at the <strong>top level</strong> of a component — never inside loops or conditions</li>
<li>Call hooks only inside React components or custom hooks</li>
<li>Never modify state directly — always use the setter function</li>
</ul>
<h2>Other hooks you will meet</h2>
<p><code>useEffect</code> runs side effects (data fetching, timers), <code>useRef</code> holds mutable values and DOM nodes, and <code>useMemo</code> caches expensive calculations.</p>`,
      codeExample: `import { useState } from "react";

function LikeButton() {
  // useState returns [currentValue, setterFunction]
  const [likes, setLikes] = useState(0);

  return (
    <button onClick={() => setLikes(likes + 1)}>
      This lesson has {likes} likes
    </button>
  );
}

// Each click calls setLikes, React re-renders,
// and the new number appears on screen.`,
    },
  ],
};
