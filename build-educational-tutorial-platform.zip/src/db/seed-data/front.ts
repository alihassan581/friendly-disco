export type SectionDef = {
  title: string;
  content: string;
  codeExample?: string;
};

export type TutorialDef = {
  tutorial: {
    title: string;
    slug: string;
    tagline: string;
    description: string;
    category: string;
    color: string;
    icon: string;
  };
  sections: SectionDef[];
};

export const htmlTutorial: TutorialDef = {
  tutorial: {
    title: "HTML",
    slug: "html",
    tagline: "The language for building web pages",
    description:
      "HTML is the standard markup language for web pages. With HTML you create the structure of every website — headings, paragraphs, links, images, tables and forms. This tutorial takes you from your very first page to building complete, well-structured documents.",
    category: "Web Development",
    color: "#ff5c39",
    icon: "Globe",
  },
  sections: [
    {
      title: "HTML Introduction",
      content: `
<h2>What is HTML?</h2>
<p>HTML stands for <strong>HyperText Markup Language</strong>. It is the standard language used to create the structure of every web page on the internet. Browsers read HTML documents and render them as the pages you see.</p>
<ul>
<li>HTML describes the <strong>structure</strong> of a web page</li>
<li>HTML consists of a series of <strong>elements</strong></li>
<li>Elements are written with <strong>tags</strong> like <code>&lt;p&gt;</code> or <code>&lt;h1&gt;</code></li>
<li>The browser uses tags to decide how to display content</li>
</ul>
<h2>A Simple HTML Document</h2>
<p>Every HTML page starts with a <code>&lt;!DOCTYPE html&gt;</code> declaration, followed by the <code>&lt;html&gt;</code> element that wraps the whole page. Inside it, the <code>&lt;head&gt;</code> contains meta information (like the page title), and the <code>&lt;body&gt;</code> contains everything visible.</p>
<div class="tip-box"><strong>Try it live</strong>Click "Try it Yourself" on the example below — change the heading text and press Run.</div>
<h2>How the Browser Reads It</h2>
<p>Tags tell the browser what each piece of content is: <code>&lt;h1&gt;</code> defines the largest heading, <code>&lt;p&gt;</code> defines a paragraph, and <code>&lt;a&gt;</code> defines a hyperlink. Only the content inside <code>&lt;body&gt;</code> is shown on the page.</p>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>My First Page</title>
</head>
<body>

  <h1>My First Heading</h1>
  <p>My first paragraph. HTML is easier than it looks!</p>

</body>
</html>`,
    },
    {
      title: "HTML Editors",
      content: `
<h2>Write HTML with any text editor</h2>
<p>You don't need special software to write HTML — a plain text editor is enough. Professionals use code editors like <strong>Visual Studio Code</strong>, <strong>Sublime Text</strong> or <strong>Zed</strong> because they add syntax highlighting, auto-completion and error hints.</p>
<h2>Create your first page in 4 steps</h2>
<ol>
<li>Open your editor and create a new file</li>
<li>Write (or copy) the HTML example below</li>
<li>Save the file as <code>index.html</code></li>
<li>Double-click the file to open it in your browser</li>
</ol>
<div class="note-box"><strong>Note</strong>Always save HTML files with the <code>.html</code> or <code>.htm</code> extension so the browser knows how to open them.</div>
<h2>Our free online editor</h2>
<p>With the Codecampus Tryit Editor you can skip the setup entirely — edit code on the left and watch the page update live on the right. Every example in this tutorial opens there with one click.</p>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Page Title</title>
</head>
<body style="font-family: sans-serif; background: #f4f4ee; padding: 2rem;">

  <h1>This is a Heading</h1>
  <p>This is a paragraph, saved as a real file called index.html.</p>
  <p>Professional developers write HTML every day in VS Code.</p>

</body>
</html>`,
    },
    {
      title: "HTML Basic",
      content: `
<h2>The skeleton of every page</h2>
<p>All HTML documents share the same basic structure: a doctype, an <code>&lt;html&gt;</code> root, a <code>&lt;head&gt;</code> for metadata and a <code>&lt;body&gt;</code> for visible content.</p>
<h2>Headings &amp; paragraphs</h2>
<p>HTML offers six levels of headings, <code>&lt;h1&gt;</code> through <code>&lt;h6&gt;</code>. Use <code>&lt;h1&gt;</code> once per page for the main title, then nest deeper levels logically. Paragraphs use the <code>&lt;p&gt;</code> tag and browsers add space between them automatically.</p>
<h2>Links and images</h2>
<p>Links are created with <code>&lt;a href="..."&gt;</code> and images with <code>&lt;img src="..." alt="..."&gt;</code>. The <code>href</code> and <code>src</code> parts are called <strong>attributes</strong> — you will learn more about them in the next chapters.</p>
<div class="tip-box"><strong>Tip</strong>Right-click any web page and choose "View page source" to see its HTML skeleton in the wild.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>HTML Basic</title>
</head>
<body style="font-family: sans-serif; padding: 2rem; line-height: 1.6;">

  <h1>Main heading of the page</h1>
  <h2>A smaller, second-level heading</h2>
  <h3>And a third-level heading</h3>

  <p>Paragraphs hold most of the text on the web.</p>
  <p>This is <a href="https://example.com">a link to example.com</a>.</p>

</body>
</html>`,
    },
    {
      title: "HTML Elements",
      content: `
<h2>Everything is an element</h2>
<p>An HTML element is everything from the start tag to the end tag, including the content in between:</p>
<p><code>&lt;p&gt;</code> My first paragraph. <code>&lt;/p&gt;</code></p>
<table>
<tr><th>Start tag</th><th>Content</th><th>End tag</th></tr>
<tr><td>&lt;h1&gt;</td><td>My Heading</td><td>&lt;/h1&gt;</td></tr>
<tr><td>&lt;p&gt;</td><td>My paragraph</td><td>&lt;/p&gt;</td></tr>
<tr><td>&lt;br&gt;</td><td><em>none — empty element</em></td><td><em>none</em></td></tr>
</table>
<h2>Nesting elements</h2>
<p>HTML elements can be nested — an element can contain other elements. The example below has a <code>&lt;div&gt;</code> containing a heading and two paragraphs. Always close the <strong>inner</strong> element before the outer one.</p>
<div class="note-box"><strong>Note</strong>Some elements have no content, like <code>&lt;br&gt;</code> (a line break) or <code>&lt;img&gt;</code>. These are called <strong>empty elements</strong> and have no end tag.</div>
<h2>Never skip the end tag</h2>
<p>Most browsers will still show a paragraph if you forget <code>&lt;/p&gt;</code>, but relying on that can produce unexpected layout bugs. Get in the habit of closing every tag.</p>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Elements</title>
</head>
<body style="font-family: sans-serif; padding: 2rem;">

  <div style="border: 2px solid #04aa6d; border-radius: 12px; padding: 20px;">
    <h2>A container element</h2>
    <p>Elements can be <strong>nested</strong> inside each other.</p>
    <p>This div holds a heading <em>and</em> two paragraphs.</p>
  </div>

</body>
</html>`,
    },
    {
      title: "HTML Attributes",
      content: `
<h2>Extra information for elements</h2>
<p>Attributes provide additional information about an element. They are always written in the <strong>start tag</strong> as <code>name="value"</code> pairs.</p>
<h2>The most important attributes</h2>
<ul>
<li><code>href</code> — the destination address of a link</li>
<li><code>src</code> — the file path of an image</li>
<li><code>alt</code> — alternative text shown if an image can't load (and read by screen readers)</li>
<li><code>style</code> — inline CSS, like <code>style="color:tomato"</code></li>
<li><code>title</code> — a tooltip shown on hover</li>
<li><code>class</code> and <code>id</code> — hooks for CSS and JavaScript</li>
</ul>
<div class="tip-box"><strong>Tip</strong>Always use lowercase attribute names and always quote the values — it keeps your markup valid and predictable.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Attributes</title>
</head>
<body style="font-family: sans-serif; padding: 2rem; line-height: 1.7;">

  <p title="I'm a tooltip">Hover over this paragraph to see the title attribute.</p>

  <a href="https://developer.mozilla.org" target="_blank">
    A link with an href attribute (opens MDN)
  </a>

  <p style="color: #ff5c39; font-weight: bold;">
    This paragraph uses the style attribute.
  </p>

</body>
</html>`,
    },
    {
      title: "HTML Formatting",
      content: `
<h2>Give text meaning</h2>
<p>HTML includes special elements for formatting text without any CSS. Some are purely visual, others carry meaning for browsers and search engines.</p>
<table>
<tr><th>Element</th><th>Result</th><th>Meaning</th></tr>
<tr><td>&lt;b&gt;</td><td><b>Bold</b></td><td>Visual bold text</td></tr>
<tr><td>&lt;strong&gt;</td><td><strong>Important</strong></td><td>Important text</td></tr>
<tr><td>&lt;i&gt;</td><td><i>Italic</i></td><td>Visual italic text</td></tr>
<tr><td>&lt;em&gt;</td><td><em>Emphasized</em></td><td>Emphasized text</td></tr>
<tr><td>&lt;mark&gt;</td><td><mark>Marked</mark></td><td>Highlighted text</td></tr>
<tr><td>&lt;del&gt;</td><td><del>Deleted</del></td><td>Removed text</td></tr>
</table>
<h2>Subscript and superscript</h2>
<p>Use <code>&lt;sub&gt;</code> for subscript (like H₂O) and <code>&lt;sup&gt;</code> for superscript (like E = mc²). These are perfect for chemistry, math and footnotes.</p>
<div class="note-box"><strong>Note</strong>Prefer <code>&lt;strong&gt;</code> over <code>&lt;b&gt;</code> and <code>&lt;em&gt;</code> over <code>&lt;i&gt;</code> — screen readers announce them with emphasis.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Formatting</title>
</head>
<body style="font-family: sans-serif; padding: 2rem; font-size: 1.15rem; line-height: 2;">

  <p>This text is <b>bold</b> and this is <strong>important</strong>.</p>
  <p>This text is <i>italic</i> and this is <em>emphasized</em>.</p>
  <p>This text is <mark>highlighted</mark> and this is <del>deleted</del>.</p>
  <p>Water is H<sub>2</sub>O and energy is E = mc<sup>2</sup>.</p>

</body>
</html>`,
    },
    {
      title: "HTML Links",
      content: `
<h2>The web is made of links</h2>
<p>Hyperlinks let visitors jump between pages — that is what makes the web a web. A link is created with the <code>&lt;a&gt;</code> (anchor) tag and its <code>href</code> attribute.</p>
<h2>Types of links</h2>
<ul>
<li><strong>Absolute URLs</strong> — a full web address, e.g. <code>https://example.com</code></li>
<li><strong>Relative URLs</strong> — a local page, e.g. <code>/about.html</code></li>
<li><strong>Email links</strong> — <code>href="mailto:hi@example.com"</code></li>
<li><strong>Bookmark links</strong> — jump to an element id on the same page with <code>href="#section"</code></li>
</ul>
<h2>Opening in a new tab</h2>
<p>Add <code>target="_blank"</code> to open the destination in a new browser tab. Anything can be a link — even an image or a button styled with CSS.</p>
<div class="tip-box"><strong>Tip</strong>Write link text that describes the destination ("Read our CSS tutorial" instead of "click here") — it's better for users and for SEO.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Links</title>
</head>
<body style="font-family: sans-serif; padding: 2rem; line-height: 2;">

  <p><a href="https://developer.mozilla.org">An absolute link to MDN</a></p>
  <p><a href="mailto:hello@codecampus.dev">Send us an email</a></p>
  <p>
    <a href="https://example.com" target="_blank"
       style="background: #ff5c39; color: white; padding: 12px 24px;
              border-radius: 999px; text-decoration: none; font-weight: bold;">
      A link styled as a button
    </a>
  </p>

</body>
</html>`,
    },
    {
      title: "HTML Images",
      content: `
<h2>Show pictures on the web</h2>
<p>The <code>&lt;img&gt;</code> tag embeds an image. It is an <strong>empty element</strong> — no end tag — and relies entirely on attributes:</p>
<ul>
<li><code>src</code> — the path to the image file</li>
<li><code>alt</code> — a text description (required for accessibility)</li>
<li><code>width</code> / <code>height</code> — the display size in pixels</li>
</ul>
<h2>Images as links</h2>
<p>Wrap an <code>&lt;img&gt;</code> inside an <code>&lt;a&gt;</code> to make the whole image clickable — the classic pattern for logos in a site header.</p>
<div class="note-box"><strong>Note</strong>Always write meaningful <code>alt</code> text. Screen readers speak it aloud, and it appears if the image fails to load.</div>
<h2>Common formats</h2>
<p>Use <strong>JPEG</strong> for photos, <strong>PNG</strong> for graphics with transparency, <strong>SVG</strong> for icons and logos (infinitely scalable) and <strong>WebP</strong> for the smallest file sizes.</p>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Images</title>
</head>
<body style="font-family: sans-serif; padding: 2rem; background: #f6f4ec;">

  <h2>An SVG image</h2>
  <img src="https://upload.wikimedia.org/wikipedia/commons/6/61/HTML5_logo_and_wordmark.svg"
       alt="HTML5 logo" width="180">

  <h2>An image that is also a link</h2>
  <a href="https://example.com">
    <img src="https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg"
         alt="React logo — click to visit example.com" width="140">
  </a>

</body>
</html>`,
    },
    {
      title: "HTML Tables",
      content: `
<h2>Structured data in rows and columns</h2>
<p>Tables display tabular data like schedules, prices and statistics. A table is built from nested elements:</p>
<ul>
<li><code>&lt;table&gt;</code> — the whole table</li>
<li><code>&lt;tr&gt;</code> — a table row</li>
<li><code>&lt;th&gt;</code> — a header cell (bold and centered by default)</li>
<li><code>&lt;td&gt;</code> — a regular data cell</li>
</ul>
<h2>Spanning cells</h2>
<p>Use <code>colspan</code> to stretch a cell across multiple columns and <code>rowspan</code> to stretch it across rows — great for schedule layouts.</p>
<div class="tip-box"><strong>Tip</strong>Use tables for <em>data</em>, not page layout. For layouts, learn CSS Grid and Flexbox instead.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Tables</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    table { border-collapse: collapse; width: 100%; max-width: 560px; }
    th, td { border: 1px solid #d8d8cf; padding: 12px 16px; text-align: left; }
    th { background: #0a1f14; color: #fff; }
    tr:nth-child(even) { background: #f1efe7; }
  </style>
</head>
<body>

  <h2>Weekly coding plan</h2>
  <table>
    <tr>
      <th>Day</th>
      <th>Topic</th>
      <th>Minutes</th>
    </tr>
    <tr><td>Monday</td><td>HTML basics</td><td>45</td></tr>
    <tr><td>Tuesday</td><td>CSS styling</td><td>60</td></tr>
    <tr><td>Wednesday</td><td>JavaScript logic</td><td>60</td></tr>
    <tr><td>Thursday</td><td>Build a project</td><td>90</td></tr>
  </table>

</body>
</html>`,
    },
    {
      title: "HTML Forms",
      content: `
<h2>Collect input from users</h2>
<p>Forms power search boxes, logins, checkouts and contact pages. The <code>&lt;form&gt;</code> element wraps a set of <strong>input controls</strong>:</p>
<table>
<tr><th>Element</th><th>Purpose</th></tr>
<tr><td>&lt;input type="text"&gt;</td><td>Single-line text field</td></tr>
<tr><td>&lt;input type="email"&gt;</td><td>Validated email field</td></tr>
<tr><td>&lt;input type="password"&gt;</td><td>Hidden password field</td></tr>
<tr><td>&lt;input type="checkbox"&gt;</td><td>Toggle one or many options</td></tr>
<tr><td>&lt;input type="radio"&gt;</td><td>Pick exactly one option</td></tr>
<tr><td>&lt;textarea&gt;</td><td>Multi-line text</td></tr>
<tr><td>&lt;select&gt;</td><td>Dropdown list</td></tr>
</table>
<h2>Labels and buttons</h2>
<p>Every input should have a <code>&lt;label&gt;</code> connected with the <code>for</code> attribute — clicking the label focuses its field. A <code>&lt;button type="submit"&gt;</code> sends the form.</p>
<div class="note-box"><strong>Note</strong>This example prevents actual submission with a tiny script, so you can test it safely in the editor.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Forms</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    form { max-width: 380px; display: grid; gap: 14px; }
    label { font-weight: 600; font-size: 0.9rem; }
    input, select, textarea {
      padding: 10px 12px; border: 1.5px solid #ccc;
      border-radius: 10px; font-size: 1rem; width: 100%;
    }
    button {
      background: #04aa6d; color: #062117; border: none;
      padding: 12px; border-radius: 999px;
      font-size: 1rem; font-weight: 700; cursor: pointer;
    }
  </style>
</head>
<body>

  <h2>Create your account</h2>
  <form onsubmit="event.preventDefault(); alert('Form valid — signed up!');">
    <label for="name">Full name</label>
    <input type="text" id="name" placeholder="Ada Lovelace" required>

    <label for="email">Email</label>
    <input type="email" id="email" placeholder="ada@example.com" required>

    <label for="topic">Favourite topic</label>
    <select id="topic">
      <option>HTML</option>
      <option>CSS</option>
      <option>JavaScript</option>
    </select>

    <button type="submit">Sign up</button>
  </form>

</body>
</html>`,
    },
  ],
};

export const cssTutorial: TutorialDef = {
  tutorial: {
    title: "CSS",
    slug: "css",
    tagline: "The language for styling web pages",
    description:
      "CSS controls the visual side of the web — colors, fonts, spacing, layouts and animations. Learn the cascade, selectors, the box model, flexbox and grid, and turn plain documents into beautiful responsive designs.",
    category: "Web Development",
    color: "#3b82f6",
    icon: "Palette",
  },
  sections: [
    {
      title: "CSS Introduction",
      content: `
<h2>What is CSS?</h2>
<ul>
<li>CSS stands for <strong>Cascading Style Sheets</strong></li>
<li>It describes how HTML elements look on screen: colors, fonts, spacing and layout</li>
<li>One stylesheet can control thousands of pages at once</li>
</ul>
<h2>Why CSS changed everything</h2>
<p>Before CSS, every style was crammed into HTML with tags like <code>&lt;font&gt;</code>. CSS moved presentation into separate rules, making sites faster to build, easier to redesign and friendlier to different screen sizes.</p>
<h2>Three ways to add CSS</h2>
<ul>
<li><strong>Inline</strong> — with the <code>style</code> attribute on one element</li>
<li><strong>Internal</strong> — a <code>&lt;style&gt;</code> block in the page head</li>
<li><strong>External</strong> — a separate <code>.css</code> file linked with <code>&lt;link&gt;</code> (the professional default)</li>
</ul>
<div class="tip-box"><strong>Tip</strong>Prefer external stylesheets for real projects; use internal blocks when experimenting in our editor.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>CSS Intro</title>
  <style>
    body { background: #0a1f14; color: #eafff5; font-family: sans-serif; padding: 2rem; }
    h1 { color: #04aa6d; font-size: 3rem; margin-bottom: 0; }
    p  { font-size: 1.1rem; line-height: 1.7; max-width: 480px; }
    .badge {
      display: inline-block; background: #04aa6d; color: #062117;
      padding: 6px 14px; border-radius: 999px; font-weight: 700;
    }
  </style>
</head>
<body>

  <span class="badge">Styled with CSS</span>
  <h1>Design is a language too</h1>
  <p>The same HTML can look completely different just by changing its CSS. Edit the colors above and press Run.</p>

</body>
</html>`,
    },
    {
      title: "CSS Syntax & Selectors",
      content: `
<h2>The anatomy of a rule</h2>
<p>A CSS rule has a <strong>selector</strong> (which elements) and a <strong>declaration block</strong> (what to change):</p>
<p><code>p { color: blue; font-size: 18px; }</code> — here <code>p</code> is the selector, <code>color</code> and <code>font-size</code> are properties, and the values come after each colon. Declarations end with a semicolon.</p>
<h2>Selectors you will use daily</h2>
<table>
<tr><th>Selector</th><th>Example</th><th>Selects</th></tr>
<tr><td>Element</td><td>p</td><td>All &lt;p&gt; elements</td></tr>
<tr><td>Class</td><td>.card</td><td>All elements with class="card"</td></tr>
<tr><td>ID</td><td>#hero</td><td>The one element with id="hero"</td></tr>
<tr><td>Descendant</td><td>div p</td><td>&lt;p&gt; inside a &lt;div&gt;</td></tr>
<tr><td>Group</td><td>h1, h2</td><td>Both h1 and h2</td></tr>
<tr><td>Universal</td><td>*</td><td>Every element</td></tr>
</table>
<div class="note-box"><strong>Note</strong>Class names are reusable across many elements; an <code>id</code> must be unique on the page.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Selectors</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    /* element selector */
    h2 { color: #3b82f6; }
    /* class selector */
    .card {
      background: #eff6ff; border: 2px solid #3b82f6;
      border-radius: 14px; padding: 18px; max-width: 420px;
    }
    /* id selector */
    #highlight { color: #d97706; font-weight: 700; }
    /* group selector */
    p, li { line-height: 1.7; }
  </style>
</head>
<body>

  <h2>Selector playground</h2>
  <div class="card">
    <p>This paragraph lives in an element with <span id="highlight">class="card"</span>.</p>
    <p>The orange text uses an <strong>id selector</strong>.</p>
  </div>

</body>
</html>`,
    },
    {
      title: "CSS Colors & Backgrounds",
      content: `
<h2>Four ways to write a color</h2>
<ul>
<li><strong>Names</strong> — <code>tomato</code>, <code>rebeccapurple</code></li>
<li><strong>HEX</strong> — <code>#04aa6d</code> (red, green, blue in pairs)</li>
<li><strong>RGB / RGBA</strong> — <code>rgb(4, 170, 109)</code>, where the alpha channel adds transparency</li>
<li><strong>HSL</strong> — <code>hsl(158, 95%, 34%)</code> (hue, saturation, lightness — great for palettes)</li>
</ul>
<h2>Backgrounds</h2>
<p>The <code>background-color</code> property paints any element. With <code>linear-gradient()</code> you can blend colors — no image files needed. An <code>opacity</code> value between 0 and 1 controls transparency of the entire element.</p>
<div class="tip-box"><strong>Tip</strong>Design systems often define one HSL hue and vary only saturation and lightness — instant harmonious shades.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Colors</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    .swatch {
      color: white; border-radius: 14px; padding: 22px;
      margin-bottom: 12px; font-weight: 700; max-width: 420px;
    }
    .hex  { background: #04aa6d; }
    .rgb  { background: rgb(59, 130, 246); }
    .hsl  { background: hsl(28, 95%, 55%); }
    .grad { background: linear-gradient(90deg, #04aa6d, #3b82f6); }
  </style>
</head>
<body>

  <div class="swatch hex">HEX — #04aa6d</div>
  <div class="swatch rgb">RGB — rgb(59, 130, 246)</div>
  <div class="swatch hsl">HSL — hsl(28, 95%, 55%)</div>
  <div class="swatch grad">A gradient — no image needed!</div>

</body>
</html>`,
    },
    {
      title: "CSS Box Model",
      content: `
<h2>Every element is a box</h2>
<p>CSS treats every element as a rectangular box with four layers, from inside out:</p>
<ol>
<li><strong>Content</strong> — the text or image itself</li>
<li><strong>Padding</strong> — space around the content, inside the border</li>
<li><strong>Border</strong> — the edge of the box</li>
<li><strong>Margin</strong> — transparent space pushing other elements away</li>
</ol>
<h2>Calculating the total width</h2>
<p>By default, total width = content + padding + border. The <code>box-sizing: border-box;</code> rule makes <code>width</code> include padding and border — nearly every project applies it to all elements:</p>
<p><code>* { box-sizing: border-box; }</code></p>
<div class="note-box"><strong>Note</strong>Margins of neighbouring elements can <em>collapse</em> into one — a classic CSS gotcha. When spacing looks wrong, check margins first.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Box Model</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    .margin-demo   { background: #dbeafe; padding: 18px; }
    .border-demo   { background: #93c5fd; padding: 18px; }
    .padding-demo  { background: #3b82f6; padding: 18px; }
    .content-demo  { background: white; padding: 14px; font-weight: 700; }
  </style>
</head>
<body>

  <div class="margin-demo">Margin (outer space)
    <div class="border-demo">Border area
      <div class="padding-demo">Padding
        <div class="content-demo">Content — the actual text</div>
      </div>
    </div>
  </div>

</body>
</html>`,
    },
    {
      title: "CSS Flexbox",
      content: `
<h2>One-dimensional layout, mastered</h2>
<p>Flexbox arranges items in a row <em>or</em> a column and distributes space between them. Set <code>display: flex</code> on the <strong>container</strong>, then control the children:</p>
<table>
<tr><th>Property</th><th>What it does</th></tr>
<tr><td>flex-direction</td><td>row or column</td></tr>
<tr><td>justify-content</td><td>Space along the main axis</td></tr>
<tr><td>align-items</td><td>Alignment on the cross axis</td></tr>
<tr><td>gap</td><td>Space between items</td></tr>
<tr><td>flex-wrap</td><td>Allow items to wrap to new lines</td></tr>
</table>
<h2>The center-center trick</h2>
<p><code>display: flex; justify-content: center; align-items: center;</code> — the three lines that finally made vertical centering trivial.</p>
<div class="tip-box"><strong>Tip</strong>Perfect for navbars, toolbars and card rows. Reach for Grid when you need two-dimensional control.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Flexbox</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    .row {
      display: flex; gap: 12px; justify-content: space-between;
      background: #eff6ff; border-radius: 16px; padding: 16px;
    }
    .item {
      background: #3b82f6; color: white; font-weight: 700;
      border-radius: 12px; padding: 26px 0; flex: 1; text-align: center;
    }
    .center-box {
      margin-top: 20px; height: 160px; background: #0a1f14;
      border-radius: 16px; color: #04aa6d; font-weight: 700;
      display: flex; justify-content: center; align-items: center;
    }
  </style>
</head>
<body>

  <div class="row">
    <div class="item">One</div>
    <div class="item">Two</div>
    <div class="item">Three</div>
  </div>

  <div class="center-box">Perfectly centered, both axes</div>

</body>
</html>`,
    },
    {
      title: "CSS Grid",
      content: `
<h2>Two-dimensional layout power</h2>
<p>CSS Grid lays out content in <strong>rows and columns</strong> at the same time — ideal for page layouts, galleries and dashboards. Turn it on with <code>display: grid;</code> and define tracks with <code>grid-template-columns</code>.</p>
<h2>The fractional unit</h2>
<p><code>grid-template-columns: 1fr 2fr 1fr;</code> splits the container into parts: the middle column gets twice the space of the side columns. Mix <code>fr</code> units with fixed pixels freely.</p>
<h2>Practical patterns</h2>
<ul>
<li><code>repeat(3, 1fr)</code> — three equal columns</li>
<li><code>repeat(auto-fit, minmax(220px, 1fr))</code> — a fully responsive card grid with zero media queries</li>
<li><code>grid-column: span 2;</code> — let one item stretch across two tracks</li>
</ul>
<div class="tip-box"><strong>Tip</strong>Grid for the page layout, Flexbox for the components inside it — they are partners, not rivals.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Grid</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    .gallery {
      display: grid; gap: 12px;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    }
    .card {
      border-radius: 14px; padding: 30px 18px;
      color: white; font-weight: 700; text-align: center;
      background: linear-gradient(135deg, #3b82f6, #04aa6d);
    }
    .wide { grid-column: span 2; background: linear-gradient(135deg, #8b5cf6, #ec4899); }
  </style>
</head>
<body>

  <h2>A responsive grid — resize the result pane</h2>
  <div class="gallery">
    <div class="card">1</div>
    <div class="card wide">2 — spans two tracks</div>
    <div class="card">3</div>
    <div class="card">4</div>
    <div class="card">5</div>
  </div>

</body>
</html>`,
    },
  ],
};
