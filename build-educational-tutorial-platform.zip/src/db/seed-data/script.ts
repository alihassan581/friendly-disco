import type { TutorialDef } from "./front";

export const jsTutorial: TutorialDef = {
  tutorial: {
    title: "JavaScript",
    slug: "javascript",
    tagline: "The language of the web",
    description:
      "JavaScript brings pages to life — interactivity, logic, animations and entire applications. Learn variables, functions, objects, events and the DOM, the skills behind every modern website and framework.",
    category: "Web Development",
    color: "#f0c929",
    icon: "Braces",
  },
  sections: [
    {
      title: "JS Introduction",
      content: `
<h2>What is JavaScript?</h2>
<p>JavaScript is the programming language of the browser. If HTML is the skeleton and CSS is the style, <strong>JavaScript is the brain</strong> — it reacts to clicks, validates forms, fetches data and updates the page without reloading.</p>
<h2>JavaScript can change HTML content</h2>
<p>One of the most common jobs is updating page content. The method <code>document.getElementById()</code> finds an element, and the <code>innerHTML</code> property replaces what is inside it.</p>
<div class="tip-box"><strong>Try it live</strong>Press the button in the result pane, then change the text in the script and run it again.</div>
<h2>Where JavaScript runs</h2>
<p>Every browser ships with a JavaScript engine. The same language also powers servers (Node.js), mobile apps and even desktop software — one language, everywhere.</p>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>JS Intro</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    button {
      background: #f0c929; border: none; padding: 12px 26px;
      border-radius: 999px; font-weight: 700; cursor: pointer;
      font-size: 1rem;
    }
    #demo { font-size: 1.4rem; font-weight: 700; margin-top: 18px; }
  </style>
</head>
<body>

  <h2>JavaScript changes content</h2>
  <p id="demo">I have not been clicked yet.</p>

  <button onclick="document.getElementById('demo').innerHTML = 'JavaScript wrote this!'">
    Click me
  </button>

</body>
</html>`,
    },
    {
      title: "JS Where To",
      content: `
<h2>Three places for your code</h2>
<ul>
<li><strong>Inside a script tag</strong> — <code>&lt;script&gt;</code> blocks anywhere in the document</li>
<li><strong>In an external file</strong> — <code>&lt;script src="app.js"&gt;&lt;/script&gt;</code> (recommended for projects)</li>
<li><strong>In event attributes</strong> — like <code>onclick="..."</code> for quick experiments</li>
</ul>
<h2>Scripts at the end of the body</h2>
<p>Placing <code>&lt;script&gt;</code> just before <code>&lt;/body&gt;</code> lets the page content load first, so your script can immediately find every element it needs. Scripts in the <code>&lt;head&gt;</code> can't see elements that appear later unless you defer them.</p>
<div class="note-box"><strong>Note</strong>An external file keeps HTML clean and lets the browser cache your code across pages.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <title>Where To</title>
</head>
<body style="font-family: sans-serif; padding: 2rem;">

  <h2>Script placement</h2>
  <p id="target">Waiting for the script…</p>

  <script>
    // This script sits at the end of the body.
    // The paragraph above already exists, so this works instantly:
    document.getElementById("target").innerHTML =
      "The script found me and updated my text.";
  </script>

</body>
</html>`,
    },
    {
      title: "JS Variables",
      content: `
<h2>Containers for values</h2>
<p>Variables store data your program works with. Modern JavaScript has two ways to declare them:</p>
<ul>
<li><code>let</code> — a variable that <strong>can</strong> change later</li>
<li><code>const</code> — a constant that <strong>cannot</strong> be reassigned</li>
<li><code>var</code> — the old way; avoid it in new code</li>
</ul>
<h2>Common data types</h2>
<table>
<tr><th>Type</th><th>Example</th></tr>
<tr><td>String</td><td>"Hello campus"</td></tr>
<tr><td>Number</td><td>42 or 3.14</td></tr>
<tr><td>Boolean</td><td>true / false</td></tr>
<tr><td>Array</td><td>["HTML", "CSS", "JS"]</td></tr>
<tr><td>Object</td><td>{ name: "Ada", level: 1 }</td></tr>
</table>
<div class="tip-box"><strong>Tip</strong>Default to <code>const</code>. Switch to <code>let</code> only when you know the value must change — your code becomes easier to reason about.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<body style="font-family: sans-serif; padding: 2rem; font-size: 1.1rem;">

  <h2>Variables in action</h2>
  <p id="out"></p>
  <p id="out2"></p>

  <script>
    const learner = "Ada";
    let minutes = 0;

    minutes = minutes + 25;

    document.getElementById("out").innerHTML =
      "Learner: " + learner;
    document.getElementById("out2").innerHTML =
      "Minutes coded today: " + minutes;
  </script>

</body>
</html>`,
    },
    {
      title: "JS Functions",
      content: `
<h2>Reusable blocks of logic</h2>
<p>A function groups statements so you can run them many times. You <strong>declare</strong> a function once and <strong>call</strong> it whenever you need it.</p>
<h2>Parameters and return values</h2>
<p>Functions accept <strong>parameters</strong> (input) and hand back a result with <code>return</code>. Nothing after a <code>return</code> statement runs — it exits the function immediately.</p>
<p><code>function greet(name) { return "Hello " + name; }</code></p>
<h2>Arrow functions</h2>
<p>Modern JavaScript offers a shorter syntax: <code>const add = (a, b) =&gt; a + b;</code>. Arrow functions are everywhere in React and modern codebases, so get comfortable reading them.</p>
<div class="note-box"><strong>Note</strong>Code inside a function does not run until the function is called.</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<body style="font-family: sans-serif; padding: 2rem; font-size: 1.1rem;">

  <h2>Functions</h2>
  <p id="a"></p>
  <p id="b"></p>
  <p id="c"></p>

  <script>
    function celsiusToFahrenheit(celsius) {
      return (celsius * 9 / 5) + 32;
    }

    const shout = (text) => text.toUpperCase() + "!";

    document.getElementById("a").innerHTML =
      "20°C is " + celsiusToFahrenheit(20) + "°F";
    document.getElementById("b").innerHTML =
      "30°C is " + celsiusToFahrenheit(30) + "°F";
    document.getElementById("c").innerHTML =
      shout("functions are reusable");
  </script>

</body>
</html>`,
    },
    {
      title: "JS Objects & Arrays",
      content: `
<h2>Group related data</h2>
<p><strong>Objects</strong> store named properties: <code>const course = { title: "JS", lessons: 7 };</code>. Read a property with dot notation: <code>course.title</code>.</p>
<p><strong>Arrays</strong> store ordered lists: <code>const topics = ["HTML", "CSS", "JS"];</code>. Indexes start at zero — <code>topics[0]</code> is "HTML".</p>
<h2>Array superpowers</h2>
<ul>
<li><code>push()</code> — add an item to the end</li>
<li><code>map()</code> — transform every item into a new array</li>
<li><code>filter()</code> — keep only items that pass a test</li>
<li><code>length</code> — how many items it holds</li>
</ul>
<div class="tip-box"><strong>Tip</strong>Loop over arrays with <code>for...of</code> — it reads almost like English: "for each topic of topics".</div>`,
      codeExample: `<!DOCTYPE html>
<html>
<body style="font-family: sans-serif; padding: 2rem;">

  <h2>Objects &amp; arrays</h2>
  <p id="obj"></p>
  <ul id="list"></ul>

  <script>
    const course = { title: "JavaScript", lessons: 7, free: true };
    document.getElementById("obj").innerHTML =
      course.title + " has " + course.lessons + " lessons.";

    const topics = ["HTML", "CSS", "JavaScript", "SQL"];
    let markup = "";
    for (const topic of topics) {
      markup = markup + "<li>" + topic + "</li>";
    }
    document.getElementById("list").innerHTML = markup;
  </script>

</body>
</html>`,
    },
    {
      title: "JS Events & The DOM",
      content: `
<h2>The DOM: a living map of your page</h2>
<p>When the browser loads HTML it builds the <strong>Document Object Model</strong> — a tree of objects representing every element. JavaScript can read, change, add and remove nodes of that tree at any time.</p>
<h2>Reacting to events</h2>
<p>Events fire when something happens: clicks, typing, scrolling, submitting. Attach listeners with <code>addEventListener</code> and your function runs each time the event fires.</p>
<p><code>button.addEventListener("click", handleClick);</code></p>
<h2>Reading input values</h2>
<p>Grab what the user typed via the element's <code>value</code> property — the foundation of search boxes, calculators and forms everywhere.</p>`,
      codeExample: `<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    input { padding: 10px 14px; border: 2px solid #f0c929; border-radius: 10px; font-size: 1rem; }
    button {
      margin-left: 8px; background: #0a1f14; color: #f0c929;
      border: none; padding: 12px 20px; border-radius: 10px;
      font-weight: 700; cursor: pointer;
    }
    #greeting { font-size: 1.5rem; font-weight: 700; margin-top: 20px; }
  </style>
</head>
<body>

  <h2>Events &amp; the DOM</h2>
  <input id="name" placeholder="Type your name">
  <button id="greetBtn">Greet me</button>
  <p id="greeting"></p>

  <script>
    const input = document.getElementById("name");
    const output = document.getElementById("greeting");

    document.getElementById("greetBtn").addEventListener("click", () => {
      output.innerHTML = "Welcome to Codecampus, " + input.value + "!";
    });
  </script>

</body>
</html>`,
    },
    {
      title: "JS Conditionals & Loops",
      content: `
<h2>Make decisions</h2>
<p><code>if</code> / <code>else if</code> / <code>else</code> statements run code only when a condition is true. Comparisons use <code>===</code> (strict equal), <code>!==</code>, <code>&lt;</code>, <code>&gt;</code> and friends.</p>
<div class="note-box"><strong>Note</strong>Always compare with the triple equals <code>===</code>. The double equals <code>==</code> performs type conversion and causes subtle bugs.</div>
<h2>Repeat yourself — automatically</h2>
<p>Loops run code many times: the classic <code>for</code> loop counts through a range, while <code>while</code> repeats as long as a condition stays true. In the example we build a times table with a loop.</p>
<h2>Combining both</h2>
<p>Most real logic is a loop with a condition inside: "for every item, <em>if</em> it matches, do something." Master this pairing and you can write almost any program.</p>`,
      codeExample: `<!DOCTYPE html>
<html>
<body style="font-family: sans-serif; padding: 2rem;">

  <h2>The 7 times table</h2>
  <p id="table"></p>

  <script>
    let rows = "";
    for (let i = 1; i <= 5; i++) {
      const result = 7 * i;
      const parity = (result % 2 === 0) ? "even" : "odd";
      rows = rows + "7 × " + i + " = " + result + " (" + parity + ")<br>";
    }
    document.getElementById("table").innerHTML = rows;
  </script>

</body>
</html>`,
    },
  ],
};

export const pythonTutorial: TutorialDef = {
  tutorial: {
    title: "Python",
    slug: "python",
    tagline: "The friendly language for everything",
    description:
      "Python is the world's most popular language for beginners and professionals alike — web backends, data science, automation and AI. Its clean, readable syntax makes it the perfect first programming language.",
    category: "Programming",
    color: "#3a7ca5",
    icon: "Terminal",
  },
  sections: [
    {
      title: "Python Introduction",
      content: `
<h2>Why Python?</h2>
<ul>
<li>Reads almost like English — the easiest serious language to learn</li>
<li>Runs everywhere: web servers, data pipelines, games, AI models</li>
<li>Huge ecosystem: Django, pandas, NumPy, PyTorch and millions of packages</li>
</ul>
<h2>Your first program</h2>
<p>The <code>print()</code> function outputs text to the screen. One line, no boilerplate — that is the Python way:</p>
<p><code>print("Hello, World!")</code></p>
<h2>Interpreted, not compiled</h2>
<p>Python runs line by line through an interpreter, which means you can experiment instantly in the interactive shell — type code, see results, iterate fast.</p>
<div class="tip-box"><strong>Tip</strong>Install Python from python.org, then run <code>python --version</code> in your terminal to confirm it works.</div>`,
      codeExample: `# Your first Python programs

print("Hello, World!")

# print() can output several values at once
print("Learning", "Python", "is", "fun")

# And it does math for you
print("2 + 2 =", 2 + 2)`,
    },
    {
      title: "Python Syntax",
      content: `
<h2>Indentation is the law</h2>
<p>Where other languages use curly braces, Python uses <strong>indentation</strong> to define code blocks — usually four spaces. Get the indentation wrong and Python refuses to run.</p>
<h2>Comments</h2>
<p>Everything after a <code>#</code> on a line is a comment, ignored by the interpreter. Use comments to explain <em>why</em> code exists, not what it does.</p>
<h2>Case sensitive</h2>
<p><code>name</code> and <code>Name</code> are two different variables in Python. The community convention is <code>snake_case</code> for variables and functions, and <code>CapWords</code> for classes.</p>
<div class="note-box"><strong>Note</strong>Mixing tabs and spaces is the classic beginner trap. Configure your editor to insert 4 spaces when you press Tab.</div>`,
      codeExample: `# Python syntax essentials

score = 95          # a variable

if score >= 90:
    # this block is indented with 4 spaces
    print("Excellent work!")
    print("Grade: A")
else:
    print("Keep practicing!")

# case matters:
name = "Ada"
Name = "Grace"
print(name, "and", Name, "are different variables")`,
    },
    {
      title: "Python Variables & Types",
      content: `
<h2>Created the moment you assign</h2>
<p>Python variables need no declaration — they spring into existence when you first assign a value: <code>x = 5</code>. Python figures out the type automatically (<em>dynamic typing</em>).</p>
<h2>The core data types</h2>
<table>
<tr><th>Type</th><th>Example</th><th>Use</th></tr>
<tr><td>str</td><td>"hello"</td><td>Text</td></tr>
<tr><td>int</td><td>42</td><td>Whole numbers</td></tr>
<tr><td>float</td><td>3.14</td><td>Decimals</td></tr>
<tr><td>bool</td><td>True / False</td><td>Logic</td></tr>
<tr><td>list</td><td>["a", "b"]</td><td>Ordered, changeable</td></tr>
<tr><td>dict</td><td>{"key": "value"}</td><td>Key-value pairs</td></tr>
</table>
<h2>Checking and converting types</h2>
<p><code>type(x)</code> tells you a value's type. Convert between types with <code>int()</code>, <code>str()</code> and <code>float()</code> — essential when combining numbers with text.</p>`,
      codeExample: `# Variables and types in Python

name = "Ada"            # str
level = 1               # int
price = 9.99            # float
is_pro = False          # bool
topics = ["html", "css", "python"]   # list

print(type(name))       # <class 'str'>
print(len(topics))      # 3

# converting types
age = "25"
next_year = int(age) + 1
print("Next year you will be", next_year)`,
    },
    {
      title: "Python If…Else",
      content: `
<h2>Decisions with elif</h2>
<p>Python chains conditions with <code>if</code>, <code>elif</code> (short for "else if") and <code>else</code>. Only the first matching branch runs.</p>
<h2>Comparison and logic operators</h2>
<ul>
<li><code>==</code>, <code>!=</code>, <code>&lt;</code>, <code>&gt;</code>, <code>&lt;=</code>, <code>&gt;=</code></li>
<li><code>and</code>, <code>or</code>, <code>not</code> — plain-English logic</li>
<li><code>in</code> — membership test, e.g. <code>"css" in topics</code></li>
</ul>
<h2>One-line conditionals</h2>
<p>For simple either-or values, Python has a compact form: <code>status = "adult" if age &gt;= 18 else "minor"</code>.</p>`,
      codeExample: `# Decisions in Python

temperature = 31

if temperature > 30:
    print("It's hot — stay hydrated!")
elif temperature > 20:
    print("Perfect weather.")
else:
    print("Bring a jacket.")

# logic operators
has_ticket = True
is_vip = False

if has_ticket and not is_vip:
    print("General admission, welcome!")`,
    },
    {
      title: "Python Loops & Functions",
      content: `
<h2>for and while</h2>
<p>A <code>for</code> loop iterates over any sequence — lists, strings, or <code>range()</code>. A <code>while</code> loop repeats until its condition becomes false. Use <code>break</code> to exit early and <code>continue</code> to skip an iteration.</p>
<h2>Define your own tools with def</h2>
<p>Functions are created with <code>def</code>, take parameters, and give back results with <code>return</code>:</p>
<p><code>def greet(name):<br>&nbsp;&nbsp;&nbsp;&nbsp;return "Hello, " + name</code></p>
<div class="tip-box"><strong>Tip</strong>If you copy-paste code a third time, turn it into a function. That instinct will carry your whole career.</div>`,
      codeExample: `# Loops and functions working together

def fizzbuzz(limit):
    for n in range(1, limit + 1):
        if n % 15 == 0:
            print("FizzBuzz")
        elif n % 3 == 0:
            print("Fizz")
        elif n % 5 == 0:
            print("Buzz")
        else:
            print(n)

fizzbuzz(15)

# while loop example
countdown = 3
while countdown > 0:
    print(countdown)
    countdown = countdown - 1
print("Blast off!")`,
    },
  ],
};
