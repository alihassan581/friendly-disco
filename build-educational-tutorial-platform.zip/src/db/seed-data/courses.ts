export type LessonDef = {
  title: string;
  duration: string;
  content: string;
};

export type CourseDef = {
  course: {
    title: string;
    slug: string;
    description: string;
    level: string;
    duration: string;
    price: string;
    color: string;
    icon: string;
  };
  lessons: LessonDef[];
};

export const courseDefs: CourseDef[] = [
  {
    course: {
      title: "Frontend Foundations",
      slug: "frontend-foundations",
      description:
        "Go from zero to building complete, responsive web pages with HTML and CSS. Along the way you will publish your first live project and learn the workflow real developers use every day.",
      level: "Beginner",
      duration: "6 weeks",
      price: "Free",
      color: "#ff5c39",
      icon: "LayoutTemplate",
    },
    lessons: [
      {
        title: "Welcome & your first page",
        duration: "8 min",
        content:
          "<p>Set up your editor, understand how the web works, and publish a real HTML page before the lesson ends.</p>",
      },
      {
        title: "Semantic HTML & structure",
        duration: "14 min",
        content:
          "<p>Header, nav, main, section and footer — learn the elements that make pages accessible and search-engine friendly.</p>",
      },
      {
        title: "Styling with modern CSS",
        duration: "18 min",
        content:
          "<p>Colors, typography, spacing and the cascade. You will style a card component from scratch, step by step.</p>",
      },
      {
        title: "Flexbox & Grid layouts",
        duration: "22 min",
        content:
          "<p>Build the classic holy-grail layout, responsive navbars and a photo grid — with plenty of live practice.</p>",
      },
      {
        title: "Capstone: your portfolio site",
        duration: "35 min",
        content:
          "<p>Combine everything into a personal portfolio: hero section, project grid, contact form and deployment.</p>",
      },
    ],
  },
  {
    course: {
      title: "JavaScript Mastery",
      slug: "javascript-mastery",
      description:
        "Move past the basics into the JavaScript that powers real applications — the DOM, events, async code, APIs and clean architecture. Finish with three portfolio-ready interactive projects.",
      level: "Intermediate",
      duration: "8 weeks",
      price: "$49",
      color: "#f0c929",
      icon: "Braces",
    },
    lessons: [
      {
        title: "Mental models: values & references",
        duration: "12 min",
        content:
          "<p>Why <code>const</code> objects can still change, how copying really works, and the equality traps to avoid.</p>",
      },
      {
        title: "DOM deep dive",
        duration: "20 min",
        content:
          "<p>Select, create and transform elements. Build a live filter and a theme switcher as you learn.</p>",
      },
      {
        title: "Events & delegation",
        duration: "16 min",
        content:
          "<p>Event objects, bubbling and the delegation pattern that keeps dynamic UIs fast and clean.</p>",
      },
      {
        title: "Async JavaScript & fetch",
        duration: "24 min",
        content:
          "<p>Promises, async/await and loading real API data with graceful loading and error states.</p>",
      },
      {
        title: "Capstone: build a task app",
        duration: "40 min",
        content:
          "<p>Add, complete, filter and persist tasks with localStorage — a complete app architecture in vanilla JS.</p>",
      },
    ],
  },
  {
    course: {
      title: "Python for Beginners",
      slug: "python-for-beginners",
      description:
        "A gentle, project-first introduction to programming with Python. No experience needed — just curiosity. You will automate boring tasks and build small tools from week one.",
      level: "Beginner",
      duration: "4 weeks",
      price: "Free",
      color: "#3a7ca5",
      icon: "Terminal",
    },
    lessons: [
      {
        title: "Setup & first script",
        duration: "10 min",
        content:
          "<p>Install Python, meet the interactive shell, and write your first script that talks back to you.</p>",
      },
      {
        title: "Numbers, strings & input",
        duration: "15 min",
        content:
          "<p>Work with text and math, read user input, and build a tiny tip calculator.</p>",
      },
      {
        title: "Lists, dicts & loops",
        duration: "18 min",
        content:
          "<p>The two workhorse data structures, and the loops that make them dance. Project: a quiz game.</p>",
      },
      {
        title: "Functions & files",
        duration: "20 min",
        content:
          "<p>Organize code into functions and read/write real files — the gateway to automation.</p>",
      },
    ],
  },
  {
    course: {
      title: "SQL & Databases",
      slug: "sql-databases",
      description:
        "Understand how applications really store data. From your first SELECT to multi-table JOINs and schema design, with practice against a real PostgreSQL database.",
      level: "All levels",
      duration: "3 weeks",
      price: "$29",
      color: "#e38c00",
      icon: "Database",
    },
    lessons: [
      {
        title: "Relational thinking",
        duration: "9 min",
        content:
          "<p>Tables, rows, keys and relationships — the mental model behind every database on earth.</p>",
      },
      {
        title: "Querying with confidence",
        duration: "16 min",
        content:
          "<p>SELECT, WHERE, ORDER BY and LIMIT drilled through dozens of bite-size exercises.</p>",
      },
      {
        title: "JOINs and aggregation",
        duration: "19 min",
        content:
          "<p>Combine tables and summarize data with GROUP BY, COUNT, SUM and AVG like an analyst.</p>",
      },
      {
        title: "Designing a schema",
        duration: "21 min",
        content:
          "<p>Normalization, indexes and constraints — design a blog database that would survive production.</p>",
      },
    ],
  },
];
