import "dotenv/config";
import { count, eq } from "drizzle-orm";
import { db, pool } from "./index";
import {
  courseLessons,
  courses,
  tutorialSections,
  tutorials,
} from "./schema";
import { slugify } from "../lib/utils";
import { cssTutorial, htmlTutorial, type TutorialDef } from "./seed-data/front";
import { jsTutorial, pythonTutorial } from "./seed-data/script";
import { reactTutorial, sqlTutorial } from "./seed-data/data";
import { courseDefs } from "./seed-data/courses";

const tutorialDefs: TutorialDef[] = [
  htmlTutorial,
  cssTutorial,
  jsTutorial,
  pythonTutorial,
  sqlTutorial,
  reactTutorial,
];

async function main() {
  const [existing] = await db.select({ total: count() }).from(tutorials);
  if (existing.total > 0) {
    console.log(`Database already has ${existing.total} tutorials — skipping seed.`);
    await pool.end();
    return;
  }

  console.log("Seeding tutorials…");
  for (const def of tutorialDefs) {
    const [t] = await db
      .insert(tutorials)
      .values({ ...def.tutorial, published: true })
      .returning({ id: tutorials.id });

    for (let i = 0; i < def.sections.length; i++) {
      const s = def.sections[i];
      await db.insert(tutorialSections).values({
        tutorialId: t.id,
        title: s.title,
        slug: slugify(s.title.replace(/^(HTML|CSS|JS|Python|SQL|React)\s+/i, "")),
        content: s.content,
        codeExample: s.codeExample ?? "",
        order: i + 1,
      });
    }
    console.log(`  ✓ ${def.tutorial.title} (${def.sections.length} lessons)`);
  }

  console.log("Seeding courses…");
  for (const def of courseDefs) {
    const [c] = await db
      .insert(courses)
      .values({ ...def.course, published: true })
      .returning({ id: courses.id });

    for (let i = 0; i < def.lessons.length; i++) {
      const l = def.lessons[i];
      await db.insert(courseLessons).values({
        courseId: c.id,
        title: l.title,
        duration: l.duration,
        content: l.content,
        order: i + 1,
      });
    }
    console.log(`  ✓ ${def.course.title} (${def.lessons.length} lessons)`);
  }

  await pool.end();
  console.log("Seeding complete.");
}

main().catch(async (err) => {
  console.error(err);
  await pool.end();
  process.exit(1);
});
