import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const tutorials = pgTable("tutorials", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 220 }).notNull().unique(),
  tagline: varchar("tagline", { length: 300 }).notNull().default(""),
  description: text("description").notNull().default(""),
  category: varchar("category", { length: 120 })
    .notNull()
    .default("Web Development"),
  color: varchar("color", { length: 20 }).notNull().default("#04aa6d"),
  icon: varchar("icon", { length: 60 }).notNull().default("Globe"),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tutorialSections = pgTable("tutorial_sections", {
  id: serial("id").primaryKey(),
  tutorialId: integer("tutorial_id")
    .notNull()
    .references(() => tutorials.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 220 }).notNull(),
  slug: varchar("slug", { length: 240 }).notNull().default(""),
  content: text("content").notNull().default(""),
  codeExample: text("code_example").notNull().default(""),
  order: integer("order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 220 }).notNull().unique(),
  description: text("description").notNull().default(""),
  level: varchar("level", { length: 60 }).notNull().default("Beginner"),
  duration: varchar("duration", { length: 60 }).notNull().default("4 weeks"),
  price: varchar("price", { length: 60 }).notNull().default("Free"),
  color: varchar("color", { length: 20 }).notNull().default("#04aa6d"),
  icon: varchar("icon", { length: 60 }).notNull().default("GraduationCap"),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const courseLessons = pgTable("course_lessons", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id")
    .notNull()
    .references(() => courses.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 220 }).notNull(),
  duration: varchar("duration", { length: 60 }).notNull().default("10 min"),
  content: text("content").notNull().default(""),
  videoUrl: varchar("video_url", { length: 500 }).notNull().default(""),
  order: integer("order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Tutorial = typeof tutorials.$inferSelect;
export type TutorialSection = typeof tutorialSections.$inferSelect;
export type Course = typeof courses.$inferSelect;
export type CourseLesson = typeof courseLessons.$inferSelect;
