const JS_KEYWORDS =
  "\\b(?:const|let|var|function|return|if|else|for|while|new|class|extends|import|export|default|async|await|try|catch|switch|case|break|continue|typeof|instanceof|this|super|true|false|null|undefined|console|document|window|alert|Math|JSON|Promise)\\b";

const SQL_KEYWORDS =
  "\\b(?:SELECT|FROM|WHERE|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|ALTER|DROP|ORDER|BY|GROUP|HAVING|JOIN|LEFT|RIGHT|INNER|OUTER|FULL|ON|AS|AND|OR|NOT|NULL|IS|LIKE|BETWEEN|LIMIT|OFFSET|DISTINCT|COUNT|SUM|AVG|MIN|MAX|PRIMARY|KEY|FOREIGN|REFERENCES|UNION|ALL|ASC|DESC|DATABASE|USE|INDEX|VIEW|EXISTS|CASE|WHEN|THEN|END|IN)\\b";

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function span(cls: string, text: string): string {
  return `<span class="${cls}">${escapeHtml(text)}</span>`;
}

function highlightTag(tag: string): string {
  // tag is a raw (unescaped) HTML tag token
  const out = escapeHtml(tag)
    // attribute = "value"
    .replace(
      /([a-zA-Z-]+)=(&quot;[^&]*?&quot;)/g,
      '<span class="tok-attr">$1</span>=<span class="tok-str">$2</span>'
    )
    // tag name
    .replace(
      /(&lt;\/?)([a-zA-Z][a-zA-Z0-9-]*)/g,
      '<span class="tok-punc">$1</span><span class="tok-tag">$2</span>'
    )
    // closing brackets
    .replace(/(\/?&gt;)$/, '<span class="tok-punc">$1</span>');
  return out;
}

export function highlightCode(code: string, lang?: string): string {
  const keywords = lang === "sql" ? SQL_KEYWORDS : JS_KEYWORDS;
  const pattern = new RegExp(
    [
      "(<!--[\\s\\S]*?-->)",
      "(/\\*[\\s\\S]*?\\*/)",
      "(//[^\\n]*)",
      "(&quot;|\"(?:[^\"\\\\\\n]|\\\\.)*\"|'(?:[^'\\\\\\n]|\\\\.)*')",
      "(<!doctype[^>]*>)",
      "(<!DOCTYPE[^>]*>)",
      "(<\\/?[a-zA-Z][^<>{}\\n]*?>)",
      `(${keywords})`,
      "(#[0-9a-fA-F]{3,8})",
      "(\\b\\d+(?:\\.\\d+)?(?:px|em|rem|%|vh|vw|deg|fr|s)?\\b)",
    ].join("|"),
    "gi"
  );

  let out = "";
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = pattern.exec(code)) !== null) {
    out += escapeHtml(code.slice(last, m.index));
    const full = m[0];
    const [, htmlCom, cssCom, jsCom, str, dt1, dt2, tag, kw, hex, num] = m;
    if (htmlCom || cssCom || jsCom) out += span("tok-com", full);
    else if (str) out += span("tok-str", full);
    else if (dt1 || dt2) out += span("tok-punc", full);
    else if (tag) out += highlightTag(full);
    else if (kw) out += span("tok-kw", full);
    else if (hex || num) out += span("tok-num", full);
    else out += escapeHtml(full);
    last = m.index + full.length;
  }
  out += escapeHtml(code.slice(last));
  return out;
}
