"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  courseLessons,
  courses,
  tutorialSections,
  tutorials,
} from "@/db/schema";
import { slugify } from "@/lib/utils";

function refresh() {
  revalidatePath("/", "layout");
}

function str(formData: FormData, key: string, fallback = ""): string {
  const value = formData.get(key);
  return value === null ? fallback : String(value).trim();
}

function num(formData: FormData, key: string, fallback = 0): number {
  const value = Number(formData.get(key));
  return Number.isFinite(value) ? value : fallback;
}

async function uniqueSlug(
  table: "tutorials" | "courses",
  wanted: string,
  ignoreId?: number
): Promise<string> {
  const base = slugify(wanted) || "untitled";
  let candidate = base;
  let i = 2;
  for (;;) {
    const rows =
      table === "tutorials"
        ? await db
            .select({ id: tutorials.id })
            .from(tutorials)
            .where(eq(tutorials.slug, candidate))
        : await db
            .select({ id: courses.id })
            .from(courses)
            .where(eq(courses.slug, candidate));
    const conflict = rows.find((r) => r.id !== ignoreId);
    if (!conflict) return candidate;
    candidate = `${base}-${i++}`;
  }
}

/* ================= TUTORIALS ================= */

export async function createTutorial(formData: FormData) {
  const title = str(formData, "title");
  const slug = await uniqueSlug("tutorials", str(formData, "slug") || title);
  const [row] = await db
    .insert(tutorials)
    .values({
      title,
      slug,
      tagline: str(formData, "tagline"),
      description: str(formData, "description"),
      category: str(formData, "category", "Web Development"),
      color: str(formData, "color", "#04aa6d"),
      icon: str(formData, "icon", "Globe"),
      published: formData.get("published") === "on",
    })
    .returning({ id: tutorials.id });
  refresh();
  redirect(`/dashboard/tutorials/${row.id}`);
}

export async function updateTutorial(id: number, formData: FormData) {
  const title = str(formData, "title");
  const slug = await uniqueSlug(
    "tutorials",
    str(formData, "slug") || title,
    id
  );
  await db
    .update(tutorials)
    .set({
      title,
      slug,
      tagline: str(formData, "tagline"),
      description: str(formData, "description"),
      category: str(formData, "category", "Web Development"),
      color: str(formData, "color", "#04aa6d"),
      icon: str(formData, "icon", "Globe"),
      published: formData.get("published") === "on",
    })
    .where(eq(tutorials.id, id));
  refresh();
  revalidatePath(`/dashboard/tutorials/${id}`);
}

export async function deleteTutorial(id: number) {
  await db.delete(tutorials).where(eq(tutorials.id, id));
  refresh();
  redirect("/dashboard/tutorials");
}

/* ================= SECTIONS ================= */

export async function createSection(tutorialId: number, formData: FormData) {
  const title = str(formData, "title");
  const existing = await db
    .select()
    .from(tutorialSections)
    .where(eq(tutorialSections.tutorialId, tutorialId));
  const nextOrder = existing.length
    ? Math.max(...existing.map((s) => s.order)) + 1
    : 1;
  await db.insert(tutorialSections).values({
    tutorialId,
    title,
    slug: slugify(str(formData, "slug") || title),
    content: str(formData, "content"),
    codeExample: str(formData, "codeExample"),
    order: num(formData, "order", nextOrder),
  });
  refresh();
  revalidatePath(`/dashboard/tutorials/${tutorialId}`);
}

export async function updateSection(
  sectionId: number,
  tutorialId: number,
  formData: FormData
) {
  const title = str(formData, "title");
  await db
    .update(tutorialSections)
    .set({
      title,
      slug: slugify(str(formData, "slug") || title),
      content: str(formData, "content"),
      codeExample: str(formData, "codeExample"),
      order: num(formData, "order"),
    })
    .where(eq(tutorialSections.id, sectionId));
  refresh();
  revalidatePath(`/dashboard/tutorials/${tutorialId}`);
  redirect(`/dashboard/tutorials/${tutorialId}`);
}

export async function deleteSection(sectionId: number, tutorialId: number) {
  await db.delete(tutorialSections).where(eq(tutorialSections.id, sectionId));
  refresh();
  revalidatePath(`/dashboard/tutorials/${tutorialId}`);
}

/* ================= COURSES ================= */

export async function createCourse(formData: FormData) {
  const title = str(formData, "title");
  const slug = await uniqueSlug("courses", str(formData, "slug") || title);
  const [row] = await db
    .insert(courses)
    .values({
      title,
      slug,
      description: str(formData, "description"),
      level: str(formData, "level", "Beginner"),
      duration: str(formData, "duration", "4 weeks"),
      price: str(formData, "price", "Free"),
      color: str(formData, "color", "#04aa6d"),
      icon: str(formData, "icon", "GraduationCap"),
      published: formData.get("published") === "on",
    })
    .returning({ id: courses.id });
  refresh();
  redirect(`/dashboard/courses/${row.id}`);
}

export async function updateCourse(id: number, formData: FormData) {
  const title = str(formData, "title");
  const slug = await uniqueSlug("courses", str(formData, "slug") || title, id);
  await db
    .update(courses)
    .set({
      title,
      slug,
      description: str(formData, "description"),
      level: str(formData, "level", "Beginner"),
      duration: str(formData, "duration", "4 weeks"),
      price: str(formData, "price", "Free"),
      color: str(formData, "color", "#04aa6d"),
      icon: str(formData, "icon", "GraduationCap"),
      published: formData.get("published") === "on",
    })
    .where(eq(courses.id, id));
  refresh();
  revalidatePath(`/dashboard/courses/${id}`);
}

export async function deleteCourse(id: number) {
  await db.delete(courses).where(eq(courses.id, id));
  refresh();
  redirect("/dashboard/courses");
}

/* ================= LESSONS ================= */

export async function createLesson(courseId: number, formData: FormData) {
  const title = str(formData, "title");
  const existing = await db
    .select()
    .from(courseLessons)
    .where(eq(courseLessons.courseId, courseId));
  const nextOrder = existing.length
    ? Math.max(...existing.map((s) => s.order)) + 1
    : 1;
  await db.insert(courseLessons).values({
    courseId,
    title,
    duration: str(formData, "duration", "10 min"),
    content: str(formData, "content"),
    videoUrl: str(formData, "videoUrl"),
    order: num(formData, "order", nextOrder),
  });
  refresh();
  revalidatePath(`/dashboard/courses/${courseId}`);
}

export async function updateLesson(
  lessonId: number,
  courseId: number,
  formData: FormData
) {
  await db
    .update(courseLessons)
    .set({
      title: str(formData, "title"),
      duration: str(formData, "duration", "10 min"),
      content: str(formData, "content"),
      videoUrl: str(formData, "videoUrl"),
      order: num(formData, "order"),
    })
    .where(eq(courseLessons.id, lessonId));
  refresh();
  revalidatePath(`/dashboard/courses/${courseId}`);
  redirect(`/dashboard/courses/${courseId}`);
}

export async function deleteLesson(lessonId: number, courseId: number) {
  await db.delete(courseLessons).where(eq(courseLessons.id, lessonId));
  refresh();
  revalidatePath(`/dashboard/courses/${courseId}`);
}
