import { asc, count, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  courseLessons,
  courses,
  tutorialSections,
  tutorials,
} from "@/db/schema";

export async function getPublishedTutorials() {
  return db
    .select()
    .from(tutorials)
    .where(eq(tutorials.published, true))
    .orderBy(asc(tutorials.id));
}

export async function getAllTutorials() {
  return db.select().from(tutorials).orderBy(asc(tutorials.id));
}

export async function getTutorialBySlug(slug: string) {
  const rows = await db
    .select()
    .from(tutorials)
    .where(eq(tutorials.slug, slug))
    .limit(1);
  return rows[0] ?? null;
}

export async function getTutorialById(id: number) {
  const rows = await db.select().from(tutorials).where(eq(tutorials.id, id));
  return rows[0] ?? null;
}

export async function getSections(tutorialId: number) {
  return db
    .select()
    .from(tutorialSections)
    .where(eq(tutorialSections.tutorialId, tutorialId))
    .orderBy(asc(tutorialSections.order), asc(tutorialSections.id));
}

export async function getSectionById(id: number) {
  const rows = await db
    .select()
    .from(tutorialSections)
    .where(eq(tutorialSections.id, id))
    .limit(1);
  return rows[0] ?? null;
}

export async function getPublishedCourses() {
  return db
    .select()
    .from(courses)
    .where(eq(courses.published, true))
    .orderBy(asc(courses.id));
}

export async function getAllCourses() {
  return db.select().from(courses).orderBy(asc(courses.id));
}

export async function getCourseBySlug(slug: string) {
  const rows = await db
    .select()
    .from(courses)
    .where(eq(courses.slug, slug))
    .limit(1);
  return rows[0] ?? null;
}

export async function getCourseById(id: number) {
  const rows = await db.select().from(courses).where(eq(courses.id, id));
  return rows[0] ?? null;
}

export async function getLessons(courseId: number) {
  return db
    .select()
    .from(courseLessons)
    .where(eq(courseLessons.courseId, courseId))
    .orderBy(asc(courseLessons.order), asc(courseLessons.id));
}

export async function getLessonById(id: number) {
  const rows = await db
    .select()
    .from(courseLessons)
    .where(eq(courseLessons.id, id))
    .limit(1);
  return rows[0] ?? null;
}

export async function getTutorialSectionCounts() {
  return db
    .select({
      tutorialId: tutorialSections.tutorialId,
      total: count(),
    })
    .from(tutorialSections)
    .groupBy(tutorialSections.tutorialId);
}

export async function getDashboardStats() {
  const [t] = await db.select({ total: count() }).from(tutorials);
  const [s] = await db.select({ total: count() }).from(tutorialSections);
  const [c] = await db.select({ total: count() }).from(courses);
  const [l] = await db.select({ total: count() }).from(courseLessons);
  const [published] = await db
    .select({ total: count() })
    .from(sql`(SELECT id FROM tutorials WHERE published = true
      UNION ALL SELECT id FROM courses WHERE published = true) AS pub`);
  return {
    tutorials: t?.total ?? 0,
    sections: s?.total ?? 0,
    courses: c?.total ?? 0,
    lessons: l?.total ?? 0,
    published: published?.total ?? 0,
  };
}
