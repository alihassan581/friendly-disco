import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Terminal } from "lucide-react";
import TryItEditor from "@/components/try-it-editor";

export const metadata: Metadata = {
  title: "Tryit Editor — Codecampus",
  description: "Write HTML, CSS and JavaScript and see the result live.",
};

const BOILERPLATE = `<!DOCTYPE html>
<html>
<head>
  <title>My Page</title>
  <style>
    body { font-family: system-ui, sans-serif; padding: 2rem; }
    h1 { color: #04aa6d; }
  </style>
</head>
<body>

  <h1>Welcome to the playground</h1>
  <p>Start typing — the result updates as you code.</p>

</body>
</html>`;

export default function TryItPage() {
  return (
    <div className="flex min-h-screen flex-col bg-forest">
      <header className="flex h-14 shrink-0 items-center gap-4 border-b border-white/10 px-4">
        <Link
          href="/"
          className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-sm font-semibold text-white/70 transition-colors hover:bg-white/10 hover:text-white"
        >
          <ArrowLeft className="size-4" />
          <span className="hidden sm:inline">Back to site</span>
        </Link>
        <span className="flex items-center gap-2 font-display text-sm font-bold text-white">
          <Terminal className="size-4 text-brand" />
          Tryit Editor <span className="font-mono text-xs text-white/40">v1.0</span>
        </span>
        <Link
          href="/tutorials"
          className="ml-auto rounded-full bg-brand px-4 py-1.5 text-xs font-bold text-forest transition-transform hover:scale-105"
        >
          Browse tutorials
        </Link>
      </header>
      <main className="flex-1 p-3 sm:p-4">
        <TryItEditor
          initialCode={BOILERPLATE}
          height={Math.max(440, 560)}
        />
      </main>
    </div>
  );
}
