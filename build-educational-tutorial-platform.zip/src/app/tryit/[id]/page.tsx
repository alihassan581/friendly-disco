import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, BookOpen, Terminal } from "lucide-react";
import { getSectionById, getTutorialById } from "@/lib/queries";
import TryItEditor from "@/components/try-it-editor";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const section = await getSectionById(Number(id));
  return { title: section ? `Tryit — ${section.title}` : "Tryit Editor" };
}

export default async function TryItExamplePage({ params }: Props) {
  const { id } = await params;
  const section = await getSectionById(Number(id));
  if (!section) notFound();
  const tutorial = await getTutorialById(section.tutorialId);

  return (
    <div className="flex min-h-screen flex-col bg-forest">
      <header className="flex h-14 shrink-0 items-center gap-4 border-b border-white/10 px-4">
        <Link
          href={
            tutorial
              ? `/tutorials/${tutorial.slug}/${section.slug}`
              : "/tutorials"
          }
          className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-sm font-semibold text-white/70 transition-colors hover:bg-white/10 hover:text-white"
        >
          <ArrowLeft className="size-4" />
          <span className="hidden sm:inline">Back to lesson</span>
        </Link>
        <span className="flex min-w-0 items-center gap-2 font-display text-sm font-bold text-white">
          <Terminal className="size-4 shrink-0 text-brand" />
          <span className="truncate">{section.title}</span>
        </span>
        <Link
          href={tutorial ? `/tutorials/${tutorial.slug}/${section.slug}` : "/tutorials"}
          className="ml-auto hidden shrink-0 items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-bold text-white transition-colors hover:bg-white/20 sm:flex"
        >
          <BookOpen className="size-3.5" />
          Read the lesson
        </Link>
      </header>
      <main className="flex-1 p-3 sm:p-4">
        <TryItEditor initialCode={section.codeExample} height={560} />
      </main>
    </div>
  );
}
