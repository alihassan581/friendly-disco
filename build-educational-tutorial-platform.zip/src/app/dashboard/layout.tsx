import type { Metadata } from "next";
import Link from "next/link";
import type { ReactNode } from "react";
import { BookOpen, GraduationCap, LayoutDashboard, Terminal } from "lucide-react";
import DashboardNav from "@/components/dashboard/dashboard-nav";

export const metadata: Metadata = {
  title: {
    default: "Dashboard",
    template: "%s · Codecampus Dashboard",
  },
};

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen bg-paper">
      <DashboardNav />

      <div className="flex min-w-0 flex-1 flex-col">
        {/* mobile bar */}
        <div className="sticky top-0 z-40 flex items-center gap-1 overflow-x-auto border-b border-white/10 bg-forest px-3 py-2.5 lg:hidden">
          <Link
            href="/dashboard"
            className="mr-2 flex shrink-0 items-center gap-2 font-display text-sm font-bold text-white"
          >
            <span className="grid size-7 place-items-center rounded-lg bg-brand text-forest">
              <Terminal className="size-4" strokeWidth={2.5} />
            </span>
            dashboard
          </Link>
          {[
            { href: "/dashboard", icon: LayoutDashboard, label: "Overview" },
            { href: "/dashboard/tutorials", icon: BookOpen, label: "Tutorials" },
            { href: "/dashboard/courses", icon: GraduationCap, label: "Courses" },
          ].map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold text-white/75 hover:bg-white/10"
            >
              <l.icon className="size-3.5" />
              {l.label}
            </Link>
          ))}
          <Link
            href="/"
            className="ml-auto shrink-0 rounded-full bg-brand px-3 py-1.5 text-xs font-bold text-forest"
          >
            View site
          </Link>
        </div>

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-8 lg:py-10">
          {children}
        </main>
      </div>
    </div>
  );
}
