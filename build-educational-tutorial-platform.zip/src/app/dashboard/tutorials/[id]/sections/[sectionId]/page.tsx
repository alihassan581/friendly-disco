import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { getSectionById, getTutorialById } from "@/lib/queries";
import { deleteSection, updateSection } from "@/lib/actions";
import { Field, TextArea, TextInput } from "@/components/dashboard/fields";
import SubmitButton from "@/components/dashboard/submit-button";
import DeleteButton from "@/components/dashboard/delete-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Edit Lesson" };

export default async function EditSectionPage({
  params,
}: {
  params: Promise<{ id: string; sectionId: string }>;
}) {
  const { id, sectionId } = await params;
  const tutorial = await getTutorialById(Number(id));
  if (!tutorial) notFound();
  const section = await getSectionById(Number(sectionId));
  if (!section || section.tutorialId !== tutorial.id) notFound();

  return (
    <div className="max-w-3xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Link
          href={`/dashboard/tutorials/${tutorial.id}`}
          className="flex items-center gap-1.5 text-sm font-bold text-ink-soft transition-colors hover:text-ink"
        >
          <ArrowLeft className="size-4" /> Back to {tutorial.title}
        </Link>
        <Link
          href={`/tutorials/${tutorial.slug}/${section.slug}`}
          target="_blank"
          className="flex items-center gap-1.5 rounded-full border border-ink/15 px-4 py-2 text-xs font-bold text-ink-soft transition-colors hover:bg-forest hover:text-white"
        >
          <ExternalLink className="size-3.5" /> Preview lesson
        </Link>
      </div>

      <h1 className="mt-4 font-display text-3xl font-bold tracking-tight">
        Edit lesson
      </h1>

      <form
        action={updateSection.bind(null, section.id, tutorial.id)}
        className="mt-8 rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-8"
      >
        <div className="grid gap-5">
          <div className="grid gap-5 sm:grid-cols-[1fr_100px]">
            <Field label="Lesson title">
              <TextInput name="title" defaultValue={section.title} required />
            </Field>
            <Field label="Order">
              <TextInput name="order" defaultValue={String(section.order)} />
            </Field>
          </div>
          <Field label="Slug">
            <TextInput name="slug" defaultValue={section.slug} />
          </Field>
          <Field
            label="Content (HTML allowed)"
            hint="Rendered inside the lesson page — use headings, lists, tables, note-box and tip-box."
          >
            <TextArea name="content" defaultValue={section.content} rows={14} />
          </Field>
          <Field
            label="Code example (optional)"
            hint="Shown in a highlighted block with a Try it Yourself button. Leave empty to hide."
          >
            <TextArea
              name="codeExample"
              defaultValue={section.codeExample}
              rows={10}
            />
          </Field>
        </div>

        <div className="mt-6 flex items-center justify-between border-t border-ink/10 pt-6">
          <SubmitButton>Save lesson</SubmitButton>
          <DeleteButton
            action={deleteSection.bind(null, section.id, tutorial.id)}
            label="Delete lesson"
            confirmMessage={`Delete lesson "${section.title}"?`}
          />
        </div>
      </form>
    </div>
  );
}
