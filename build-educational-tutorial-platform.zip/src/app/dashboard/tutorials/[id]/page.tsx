import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink, GripVertical, Pencil, Plus } from "lucide-react";
import { getSections, getTutorialById } from "@/lib/queries";
import {
  createSection,
  deleteSection,
  deleteTutorial,
  updateTutorial,
} from "@/lib/actions";
import {
  ColorInput,
  Field,
  PublishedToggle,
  SelectInput,
  TextArea,
  TextInput,
} from "@/components/dashboard/fields";
import IconPicker from "@/components/dashboard/icon-picker";
import SubmitButton from "@/components/dashboard/submit-button";
import DeleteButton from "@/components/dashboard/delete-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Edit Tutorial" };

export default async function EditTutorialPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const tutorial = await getTutorialById(Number(id));
  if (!tutorial) notFound();
  const sections = await getSections(tutorial.id);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Link
          href="/dashboard/tutorials"
          className="flex items-center gap-1.5 text-sm font-bold text-ink-soft transition-colors hover:text-ink"
        >
          <ArrowLeft className="size-4" /> Back to tutorials
        </Link>
        <Link
          href={`/tutorials/${tutorial.slug}`}
          target="_blank"
          className="flex items-center gap-1.5 rounded-full border border-ink/15 px-4 py-2 text-xs font-bold text-ink-soft transition-colors hover:bg-forest hover:text-white"
        >
          <ExternalLink className="size-3.5" /> View live
        </Link>
      </div>

      <h1 className="mt-4 font-display text-3xl font-bold tracking-tight">
        Edit: {tutorial.title}
      </h1>

      <div className="mt-8 grid items-start gap-6 lg:grid-cols-[1.15fr_1fr]">
        {/* ===== Edit form ===== */}
        <form
          action={updateTutorial.bind(null, tutorial.id)}
          className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-8"
        >
          <h2 className="font-display text-lg font-bold">Tutorial settings</h2>
          <div className="mt-5 grid gap-5 sm:grid-cols-2">
            <Field label="Title">
              <TextInput name="title" defaultValue={tutorial.title} required />
            </Field>
            <Field label="Slug">
              <TextInput name="slug" defaultValue={tutorial.slug} />
            </Field>
            <Field label="Tagline" className="sm:col-span-2">
              <TextInput name="tagline" defaultValue={tutorial.tagline} />
            </Field>
            <Field label="Description" className="sm:col-span-2">
              <TextArea
                name="description"
                defaultValue={tutorial.description}
                rows={4}
                mono={false}
              />
            </Field>
            <Field label="Category">
              <SelectInput
                name="category"
                defaultValue={tutorial.category}
                options={[
                  "Web Development",
                  "Programming",
                  "Databases",
                  "Data Science",
                  "DevOps",
                  "Design",
                ]}
              />
            </Field>
            <Field label="Brand color">
              <ColorInput name="color" defaultValue={tutorial.color} />
            </Field>
            <Field label="Icon" className="sm:col-span-2">
              <IconPicker defaultValue={tutorial.icon} color={tutorial.color} />
            </Field>
            <div className="sm:col-span-2">
              <PublishedToggle defaultChecked={tutorial.published} />
            </div>
          </div>
          <div className="mt-6 flex items-center justify-between border-t border-ink/10 pt-6">
            <SubmitButton>Save changes</SubmitButton>
            <DeleteButton
              action={deleteTutorial.bind(null, tutorial.id)}
              label="Delete tutorial"
              confirmMessage={`Delete "${tutorial.title}" and all ${sections.length} lessons? This cannot be undone.`}
            />
          </div>
        </form>

        {/* ===== Lessons ===== */}
        <div className="grid gap-6">
          <section className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm">
            <h2 className="font-display text-lg font-bold">
              Lessons{" "}
              <span className="ml-1 rounded-full bg-cream px-2.5 py-0.5 text-xs font-bold text-ink-soft">
                {sections.length}
              </span>
            </h2>
            {sections.length === 0 ? (
              <p className="mt-4 rounded-2xl border border-dashed border-ink/15 py-8 text-center text-sm text-ink/40">
                No lessons yet — add the first one below.
              </p>
            ) : (
              <ul className="mt-4 grid gap-2">
                {sections.map((s) => (
                  <li
                    key={s.id}
                    className="flex items-center gap-3 rounded-xl border border-ink/10 bg-paper px-3 py-2.5"
                  >
                    <GripVertical className="size-4 shrink-0 text-ink/20" />
                    <span className="w-6 shrink-0 font-mono text-xs font-bold text-ink/35">
                      {s.order}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-sm font-bold">
                      {s.title}
                    </span>
                    <Link
                      href={`/dashboard/tutorials/${tutorial.id}/sections/${s.id}`}
                      className="grid size-7 shrink-0 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-brand hover:text-forest"
                      title="Edit lesson"
                    >
                      <Pencil className="size-3" />
                    </Link>
                    <DeleteButton
                      action={deleteSection.bind(null, s.id, tutorial.id)}
                      iconOnly
                      confirmMessage={`Delete lesson "${s.title}"?`}
                    />
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Add lesson */}
          <section className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm">
            <h2 className="flex items-center gap-2 font-display text-lg font-bold">
              <span className="grid size-7 place-items-center rounded-lg bg-brand/15 text-brand-deep">
                <Plus className="size-4" />
              </span>
              Add a lesson
            </h2>
            <form
              action={createSection.bind(null, tutorial.id)}
              className="mt-5 grid gap-4"
            >
              <Field label="Lesson title">
                <TextInput
                  name="title"
                  placeholder={`e.g. ${tutorial.title} Elements`}
                  required
                />
              </Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Order">
                  <TextInput
                    name="order"
                    placeholder={String((sections.at(-1)?.order ?? 0) + 1)}
                  />
                </Field>
                <Field label="Slug" hint="Auto-generated if empty.">
                  <TextInput name="slug" placeholder="elements" />
                </Field>
              </div>
              <Field
                label="Content (HTML allowed)"
                hint="Supports <h2>, <p>, <ul>, <table>, <code>, note-box and tip-box divs."
              >
                <TextArea
                  name="content"
                  rows={6}
                  placeholder="<h2>Introduction</h2><p>Write the lesson body here…</p>"
                />
              </Field>
              <Field
                label="Code example (optional)"
                hint="A runnable HTML/CSS/JS snippet — gets a Try it Yourself button."
              >
                <TextArea
                  name="codeExample"
                  rows={6}
                  placeholder="<!DOCTYPE html>&#10;<html>…"
                />
              </Field>
              <SubmitButton variant="dark" className="w-fit">
                Add lesson
              </SubmitButton>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
}
