import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Sparkles } from "lucide-react";
import { createTutorial } from "@/lib/actions";
import {
  ColorInput,
  Field,
  PublishedToggle,
  SelectInput,
  TextArea,
  TextInput,
} from "@/components/dashboard/fields";
import IconPicker from "@/components/dashboard/icon-picker";
import SubmitButton from "@/components/dashboard/submit-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "New Tutorial" };

export default function NewTutorialPage() {
  return (
    <div className="max-w-3xl">
      <Link
        href="/dashboard/tutorials"
        className="flex w-fit items-center gap-1.5 text-sm font-bold text-ink-soft transition-colors hover:text-ink"
      >
        <ArrowLeft className="size-4" /> Back to tutorials
      </Link>

      <div className="mt-4 flex items-center gap-3">
        <span className="grid size-12 place-items-center rounded-2xl bg-brand/15 text-brand-deep">
          <Sparkles className="size-6" />
        </span>
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">
            Upload a tutorial
          </h1>
          <p className="text-sm text-ink-soft">
            Fill in the basics — you&apos;ll add lessons right after.
          </p>
        </div>
      </div>

      <form
        action={createTutorial}
        className="mt-8 rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-8"
      >
        <div className="grid gap-6">
          <div className="grid gap-6 sm:grid-cols-2">
            <Field label="Title" className="sm:col-span-2">
              <TextInput name="title" placeholder="e.g. HTML" required />
            </Field>
            <Field label="Slug" hint="Leave empty to auto-generate from the title.">
              <TextInput name="slug" placeholder="e.g. html" />
            </Field>
            <Field label="Category">
              <SelectInput
                name="category"
                defaultValue="Web Development"
                options={[
                  "Web Development",
                  "Programming",
                  "Databases",
                  "Data Science",
                  "DevOps",
                  "Design",
                ]}
              />
            </Field>
            <Field label="Tagline" className="sm:col-span-2">
              <TextInput
                name="tagline"
                placeholder="e.g. The language for building web pages"
              />
            </Field>
            <Field label="Description" className="sm:col-span-2">
              <TextArea
                name="description"
                rows={4}
                mono={false}
                placeholder="A short description shown on the tutorial landing page."
              />
            </Field>
            <Field label="Brand color">
              <ColorInput name="color" />
            </Field>
            <Field label="Icon">
              <IconPicker />
            </Field>
          </div>

          <PublishedToggle defaultChecked />

          <div className="flex items-center gap-3 border-t border-ink/10 pt-6">
            <SubmitButton>Create tutorial</SubmitButton>
            <Link
              href="/dashboard/tutorials"
              className="rounded-full border border-ink/15 px-6 py-2.5 text-sm font-bold text-ink-soft hover:bg-cream"
            >
              Cancel
            </Link>
          </div>
        </div>
      </form>
    </div>
  );
}
