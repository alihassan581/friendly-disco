import type { Metadata } from "next";
import Link from "next/link";
import { ExternalLink, Pencil, Plus } from "lucide-react";
import { getAllTutorials, getTutorialSectionCounts } from "@/lib/queries";
import { getIcon } from "@/lib/icons";
import { deleteTutorial } from "@/lib/actions";
import DeleteButton from "@/components/dashboard/delete-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Manage Tutorials" };

export default async function DashboardTutorialsPage() {
  const [tutorials, counts] = await Promise.all([
    getAllTutorials(),
    getTutorialSectionCounts(),
  ]);
  const countMap = new Map(counts.map((c) => [c.tutorialId, c.total]));

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
            Content
          </p>
          <h1 className="mt-2 font-display text-4xl font-bold tracking-tight">
            Tutorials
          </h1>
        </div>
        <Link
          href="/dashboard/tutorials/new"
          className="flex items-center gap-2 rounded-full bg-brand px-5 py-2.5 text-sm font-bold text-forest shadow-lg shadow-brand/25 transition-transform hover:scale-105"
        >
          <Plus className="size-4" /> New tutorial
        </Link>
      </div>

      {tutorials.length === 0 ? (
        <div className="mt-10 rounded-3xl border border-dashed border-ink/20 bg-white py-20 text-center">
          <p className="font-display text-xl font-bold">No tutorials yet</p>
          <p className="mt-1 text-sm text-ink-soft">
            Upload your first tutorial to get started.
          </p>
        </div>
      ) : (
        <div className="mt-8 overflow-hidden rounded-3xl border border-ink/10 bg-white shadow-sm">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-ink/10 bg-cream/60 text-xs font-bold uppercase tracking-widest text-ink/40">
                <th className="px-6 py-4">Tutorial</th>
                <th className="hidden px-6 py-4 md:table-cell">Category</th>
                <th className="hidden px-6 py-4 sm:table-cell">Lessons</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/5">
              {tutorials.map((t) => {
                const Icon = getIcon(t.icon);
                return (
                  <tr key={t.id} className="transition-colors hover:bg-cream/40">
                    <td className="px-6 py-4">
                      <span className="flex items-center gap-3">
                        <span
                          className="grid size-10 shrink-0 place-items-center rounded-xl"
                          style={{
                            backgroundColor: `${t.color}1c`,
                            color: t.color,
                          }}
                        >
                          <Icon className="size-5" />
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate text-sm font-bold">
                            {t.title}
                          </span>
                          <span className="block truncate font-mono text-xs text-ink/35">
                            /tutorials/{t.slug}
                          </span>
                        </span>
                      </span>
                    </td>
                    <td className="hidden px-6 py-4 md:table-cell">
                      <span className="rounded-full bg-cream px-3 py-1 text-xs font-bold text-ink-soft">
                        {t.category}
                      </span>
                    </td>
                    <td className="hidden px-6 py-4 text-sm font-bold sm:table-cell">
                      {countMap.get(t.id) ?? 0}
                    </td>
                    <td className="px-6 py-4">
                      {t.published ? (
                        <span className="rounded-full bg-brand/15 px-3 py-1 text-xs font-bold text-brand-deep">
                          Published
                        </span>
                      ) : (
                        <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">
                          Draft
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className="flex items-center justify-end gap-2">
                        <Link
                          href={`/tutorials/${t.slug}`}
                          className="grid size-8 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-forest hover:text-white"
                          title="View live"
                        >
                          <ExternalLink className="size-3.5" />
                        </Link>
                        <Link
                          href={`/dashboard/tutorials/${t.id}`}
                          className="grid size-8 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-brand hover:text-forest"
                          title="Edit"
                        >
                          <Pencil className="size-3.5" />
                        </Link>
                        <DeleteButton
                          action={deleteTutorial.bind(null, t.id)}
                          iconOnly
                          confirmMessage={`Delete "${t.title}" and all its lessons?`}
                        />
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
