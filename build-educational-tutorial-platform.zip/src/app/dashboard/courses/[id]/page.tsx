import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Clock3, ExternalLink, GripVertical, Pencil, Plus } from "lucide-react";
import { getCourseById, getLessons } from "@/lib/queries";
import {
  createLesson,
  deleteCourse,
  deleteLesson,
  updateCourse,
} from "@/lib/actions";
import {
  ColorInput,
  Field,
  PublishedToggle,
  SelectInput,
  TextArea,
  TextInput,
} from "@/components/dashboard/fields";
import IconPicker from "@/components/dashboard/icon-picker";
import SubmitButton from "@/components/dashboard/submit-button";
import DeleteButton from "@/components/dashboard/delete-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Edit Course" };

export default async function EditCoursePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const course = await getCourseById(Number(id));
  if (!course) notFound();
  const lessons = await getLessons(course.id);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Link
          href="/dashboard/courses"
          className="flex items-center gap-1.5 text-sm font-bold text-ink-soft transition-colors hover:text-ink"
        >
          <ArrowLeft className="size-4" /> Back to courses
        </Link>
        <Link
          href={`/courses/${course.slug}`}
          target="_blank"
          className="flex items-center gap-1.5 rounded-full border border-ink/15 px-4 py-2 text-xs font-bold text-ink-soft transition-colors hover:bg-forest hover:text-white"
        >
          <ExternalLink className="size-3.5" /> View live
        </Link>
      </div>

      <h1 className="mt-4 font-display text-3xl font-bold tracking-tight">
        Edit: {course.title}
      </h1>

      <div className="mt-8 grid items-start gap-6 lg:grid-cols-[1.15fr_1fr]">
        {/* ===== Edit form ===== */}
        <form
          action={updateCourse.bind(null, course.id)}
          className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-8"
        >
          <h2 className="font-display text-lg font-bold">Course settings</h2>
          <div className="mt-5 grid gap-5 sm:grid-cols-2">
            <Field label="Title" className="sm:col-span-2">
              <TextInput name="title" defaultValue={course.title} required />
            </Field>
            <Field label="Slug">
              <TextInput name="slug" defaultValue={course.slug} />
            </Field>
            <Field label="Level">
              <SelectInput
                name="level"
                defaultValue={course.level}
                options={["Beginner", "Intermediate", "Advanced", "All levels"]}
              />
            </Field>
            <Field label="Duration">
              <TextInput name="duration" defaultValue={course.duration} />
            </Field>
            <Field label="Price">
              <TextInput name="price" defaultValue={course.price} />
            </Field>
            <Field label="Description" className="sm:col-span-2">
              <TextArea
                name="description"
                defaultValue={course.description}
                rows={4}
                mono={false}
              />
            </Field>
            <Field label="Brand color">
              <ColorInput name="color" defaultValue={course.color} />
            </Field>
            <Field label="Icon" className="sm:col-span-2">
              <IconPicker defaultValue={course.icon} color={course.color} />
            </Field>
            <div className="sm:col-span-2">
              <PublishedToggle defaultChecked={course.published} />
            </div>
          </div>
          <div className="mt-6 flex items-center justify-between border-t border-ink/10 pt-6">
            <SubmitButton>Save changes</SubmitButton>
            <DeleteButton
              action={deleteCourse.bind(null, course.id)}
              label="Delete course"
              confirmMessage={`Delete "${course.title}" and all ${lessons.length} lessons? This cannot be undone.`}
            />
          </div>
        </form>

        {/* ===== Lessons ===== */}
        <div className="grid gap-6">
          <section className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm">
            <h2 className="font-display text-lg font-bold">
              Lessons{" "}
              <span className="ml-1 rounded-full bg-cream px-2.5 py-0.5 text-xs font-bold text-ink-soft">
                {lessons.length}
              </span>
            </h2>
            {lessons.length === 0 ? (
              <p className="mt-4 rounded-2xl border border-dashed border-ink/15 py-8 text-center text-sm text-ink/40">
                No lessons yet — add the first one below.
              </p>
            ) : (
              <ul className="mt-4 grid gap-2">
                {lessons.map((l) => (
                  <li
                    key={l.id}
                    className="flex items-center gap-3 rounded-xl border border-ink/10 bg-paper px-3 py-2.5"
                  >
                    <GripVertical className="size-4 shrink-0 text-ink/20" />
                    <span className="w-6 shrink-0 font-mono text-xs font-bold text-ink/35">
                      {l.order}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-bold">
                        {l.title}
                      </span>
                      <span className="flex items-center gap-1 text-xs text-ink/40">
                        <Clock3 className="size-3" />
                        {l.duration}
                      </span>
                    </span>
                    <Link
                      href={`/dashboard/courses/${course.id}/lessons/${l.id}`}
                      className="grid size-7 shrink-0 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-brand hover:text-forest"
                      title="Edit lesson"
                    >
                      <Pencil className="size-3" />
                    </Link>
                    <DeleteButton
                      action={deleteLesson.bind(null, l.id, course.id)}
                      iconOnly
                      confirmMessage={`Delete lesson "${l.title}"?`}
                    />
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Add lesson */}
          <section className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm">
            <h2 className="flex items-center gap-2 font-display text-lg font-bold">
              <span className="grid size-7 place-items-center rounded-lg bg-brand/15 text-brand-deep">
                <Plus className="size-4" />
              </span>
              Add a lesson
            </h2>
            <form action={createLesson.bind(null, course.id)} className="mt-5 grid gap-4">
              <Field label="Lesson title">
                <TextInput name="title" placeholder="e.g. Setting up your workspace" required />
              </Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Duration">
                  <TextInput name="duration" placeholder="e.g. 12 min" />
                </Field>
                <Field label="Order">
                  <TextInput
                    name="order"
                    placeholder={String((lessons.at(-1)?.order ?? 0) + 1)}
                  />
                </Field>
              </div>
              <Field label="Video URL" hint="Optional — link to a hosted video.">
                <TextInput name="videoUrl" placeholder="https://…" />
              </Field>
              <Field label="Summary (HTML allowed)">
                <TextArea
                  name="content"
                  rows={5}
                  placeholder="<p>What this lesson covers…</p>"
                />
              </Field>
              <SubmitButton variant="dark" className="w-fit">
                Add lesson
              </SubmitButton>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
}
