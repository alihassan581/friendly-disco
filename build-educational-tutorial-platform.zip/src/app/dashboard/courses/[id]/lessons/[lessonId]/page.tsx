import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { getCourseById, getLessonById } from "@/lib/queries";
import { deleteLesson, updateLesson } from "@/lib/actions";
import { Field, TextArea, TextInput } from "@/components/dashboard/fields";
import SubmitButton from "@/components/dashboard/submit-button";
import DeleteButton from "@/components/dashboard/delete-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Edit Course Lesson" };

export default async function EditLessonPage({
  params,
}: {
  params: Promise<{ id: string; lessonId: string }>;
}) {
  const { id, lessonId } = await params;
  const course = await getCourseById(Number(id));
  if (!course) notFound();
  const lesson = await getLessonById(Number(lessonId));
  if (!lesson || lesson.courseId !== course.id) notFound();

  return (
    <div className="max-w-3xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Link
          href={`/dashboard/courses/${course.id}`}
          className="flex items-center gap-1.5 text-sm font-bold text-ink-soft transition-colors hover:text-ink"
        >
          <ArrowLeft className="size-4" /> Back to {course.title}
        </Link>
        <Link
          href={`/courses/${course.slug}`}
          target="_blank"
          className="flex items-center gap-1.5 rounded-full border border-ink/15 px-4 py-2 text-xs font-bold text-ink-soft transition-colors hover:bg-forest hover:text-white"
        >
          <ExternalLink className="size-3.5" /> Preview course
        </Link>
      </div>

      <h1 className="mt-4 font-display text-3xl font-bold tracking-tight">
        Edit lesson
      </h1>

      <form
        action={updateLesson.bind(null, lesson.id, course.id)}
        className="mt-8 rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-8"
      >
        <div className="grid gap-5">
          <div className="grid gap-5 sm:grid-cols-[1fr_110px]">
            <Field label="Lesson title">
              <TextInput name="title" defaultValue={lesson.title} required />
            </Field>
            <Field label="Order">
              <TextInput name="order" defaultValue={String(lesson.order)} />
            </Field>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Duration">
              <TextInput name="duration" defaultValue={lesson.duration} />
            </Field>
            <Field label="Video URL">
              <TextInput name="videoUrl" defaultValue={lesson.videoUrl} />
            </Field>
          </div>
          <Field label="Summary (HTML allowed)">
            <TextArea name="content" defaultValue={lesson.content} rows={8} />
          </Field>
        </div>

        <div className="mt-6 flex items-center justify-between border-t border-ink/10 pt-6">
          <SubmitButton>Save lesson</SubmitButton>
          <DeleteButton
            action={deleteLesson.bind(null, lesson.id, course.id)}
            label="Delete lesson"
            confirmMessage={`Delete lesson "${lesson.title}"?`}
          />
        </div>
      </form>
    </div>
  );
}
