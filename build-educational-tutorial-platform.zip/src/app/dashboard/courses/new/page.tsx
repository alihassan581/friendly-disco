import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, GraduationCap } from "lucide-react";
import { createCourse } from "@/lib/actions";
import {
  ColorInput,
  Field,
  PublishedToggle,
  SelectInput,
  TextArea,
  TextInput,
} from "@/components/dashboard/fields";
import IconPicker from "@/components/dashboard/icon-picker";
import SubmitButton from "@/components/dashboard/submit-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "New Course" };

export default function NewCoursePage() {
  return (
    <div className="max-w-3xl">
      <Link
        href="/dashboard/courses"
        className="flex w-fit items-center gap-1.5 text-sm font-bold text-ink-soft transition-colors hover:text-ink"
      >
        <ArrowLeft className="size-4" /> Back to courses
      </Link>

      <div className="mt-4 flex items-center gap-3">
        <span className="grid size-12 place-items-center rounded-2xl bg-brand/15 text-brand-deep">
          <GraduationCap className="size-6" />
        </span>
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">
            Upload a course
          </h1>
          <p className="text-sm text-ink-soft">
            Set the course details — lessons get added on the next screen.
          </p>
        </div>
      </div>

      <form
        action={createCourse}
        className="mt-8 rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-8"
      >
        <div className="grid gap-6">
          <div className="grid gap-6 sm:grid-cols-2">
            <Field label="Title" className="sm:col-span-2">
              <TextInput
                name="title"
                placeholder="e.g. Modern JavaScript from Zero"
                required
              />
            </Field>
            <Field label="Slug" hint="Leave empty to auto-generate from the title.">
              <TextInput name="slug" placeholder="modern-javascript" />
            </Field>
            <Field label="Level">
              <SelectInput
                name="level"
                defaultValue="Beginner"
                options={["Beginner", "Intermediate", "Advanced", "All levels"]}
              />
            </Field>
            <Field label="Duration">
              <TextInput name="duration" placeholder="e.g. 6 weeks" />
            </Field>
            <Field label="Price">
              <TextInput name="price" placeholder="Free" defaultValue="Free" />
            </Field>
            <Field label="Description" className="sm:col-span-2">
              <TextArea
                name="description"
                rows={4}
                mono={false}
                placeholder="What will students learn in this course?"
              />
            </Field>
            <Field label="Brand color">
              <ColorInput name="color" />
            </Field>
            <Field label="Icon">
              <IconPicker defaultValue="GraduationCap" />
            </Field>
          </div>

          <PublishedToggle defaultChecked />

          <div className="flex items-center gap-3 border-t border-ink/10 pt-6">
            <SubmitButton>Create course</SubmitButton>
            <Link
              href="/dashboard/courses"
              className="rounded-full border border-ink/15 px-6 py-2.5 text-sm font-bold text-ink-soft hover:bg-cream"
            >
              Cancel
            </Link>
          </div>
        </div>
      </form>
    </div>
  );
}
