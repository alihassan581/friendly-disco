import type { Metadata } from "next";
import Link from "next/link";
import { ExternalLink, Pencil, Plus } from "lucide-react";
import { getAllCourses, getLessons } from "@/lib/queries";
import { getIcon } from "@/lib/icons";
import { deleteCourse } from "@/lib/actions";
import DeleteButton from "@/components/dashboard/delete-button";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Manage Courses" };

export default async function DashboardCoursesPage() {
  const courses = await getAllCourses();
  const lessonCounts = await Promise.all(
    courses.map(async (c) => (await getLessons(c.id)).length)
  );

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
            Content
          </p>
          <h1 className="mt-2 font-display text-4xl font-bold tracking-tight">
            Courses
          </h1>
        </div>
        <Link
          href="/dashboard/courses/new"
          className="flex items-center gap-2 rounded-full bg-brand px-5 py-2.5 text-sm font-bold text-forest shadow-lg shadow-brand/25 transition-transform hover:scale-105"
        >
          <Plus className="size-4" /> New course
        </Link>
      </div>

      {courses.length === 0 ? (
        <div className="mt-10 rounded-3xl border border-dashed border-ink/20 bg-white py-20 text-center">
          <p className="font-display text-xl font-bold">No courses yet</p>
          <p className="mt-1 text-sm text-ink-soft">
            Upload your first course to get started.
          </p>
        </div>
      ) : (
        <div className="mt-8 overflow-hidden rounded-3xl border border-ink/10 bg-white shadow-sm">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-ink/10 bg-cream/60 text-xs font-bold uppercase tracking-widest text-ink/40">
                <th className="px-6 py-4">Course</th>
                <th className="hidden px-6 py-4 md:table-cell">Level</th>
                <th className="hidden px-6 py-4 sm:table-cell">Lessons</th>
                <th className="hidden px-6 py-4 lg:table-cell">Price</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/5">
              {courses.map((c, i) => {
                const Icon = getIcon(c.icon);
                return (
                  <tr key={c.id} className="transition-colors hover:bg-cream/40">
                    <td className="px-6 py-4">
                      <span className="flex items-center gap-3">
                        <span
                          className="grid size-10 shrink-0 place-items-center rounded-xl"
                          style={{
                            backgroundColor: `${c.color}1c`,
                            color: c.color,
                          }}
                        >
                          <Icon className="size-5" />
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate text-sm font-bold">
                            {c.title}
                          </span>
                          <span className="block truncate font-mono text-xs text-ink/35">
                            /courses/{c.slug}
                          </span>
                        </span>
                      </span>
                    </td>
                    <td className="hidden px-6 py-4 md:table-cell">
                      <span className="rounded-full bg-cream px-3 py-1 text-xs font-bold text-ink-soft">
                        {c.level}
                      </span>
                    </td>
                    <td className="hidden px-6 py-4 text-sm font-bold sm:table-cell">
                      {lessonCounts[i]}
                    </td>
                    <td className="hidden px-6 py-4 text-sm font-bold lg:table-cell">
                      {c.price}
                    </td>
                    <td className="px-6 py-4">
                      {c.published ? (
                        <span className="rounded-full bg-brand/15 px-3 py-1 text-xs font-bold text-brand-deep">
                          Published
                        </span>
                      ) : (
                        <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">
                          Draft
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className="flex items-center justify-end gap-2">
                        <Link
                          href={`/courses/${c.slug}`}
                          className="grid size-8 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-forest hover:text-white"
                          title="View live"
                        >
                          <ExternalLink className="size-3.5" />
                        </Link>
                        <Link
                          href={`/dashboard/courses/${c.id}`}
                          className="grid size-8 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-brand hover:text-forest"
                          title="Edit"
                        >
                          <Pencil className="size-3.5" />
                        </Link>
                        <DeleteButton
                          action={deleteCourse.bind(null, c.id)}
                          iconOnly
                          confirmMessage={`Delete "${c.title}" and all its lessons?`}
                        />
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
