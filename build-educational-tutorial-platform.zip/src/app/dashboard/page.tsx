import Link from "next/link";
import {
  ArrowUpRight,
  BookOpen,
  Eye,
  FileText,
  GraduationCap,
  LayoutList,
  Pencil,
  Plus,
  TrendingUp,
} from "lucide-react";
import {
  getAllCourses,
  getAllTutorials,
  getDashboardStats,
  getSections,
  getLessons,
} from "@/lib/queries";
import { getIcon } from "@/lib/icons";

export const dynamic = "force-dynamic";

export default async function DashboardOverview() {
  const [stats, tutorials, courses] = await Promise.all([
    getDashboardStats(),
    getAllTutorials(),
    getAllCourses(),
  ]);

  const recentTutorials = [...tutorials]
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 5);
  const recentCourses = [...courses]
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 5);

  const tutorialLessons = await Promise.all(
    recentTutorials.map(async (t) => (await getSections(t.id)).length)
  );
  const courseLessons = await Promise.all(
    recentCourses.map(async (c) => (await getLessons(c.id)).length)
  );

  const cards = [
    { label: "Tutorials", value: stats.tutorials, icon: BookOpen, tint: "#04aa6d" },
    { label: "Tutorial lessons", value: stats.sections, icon: LayoutList, tint: "#3b82f6" },
    { label: "Courses", value: stats.courses, icon: GraduationCap, tint: "#f59e0b" },
    { label: "Course lessons", value: stats.lessons, icon: FileText, tint: "#8b5cf6" },
    { label: "Published items", value: stats.published, icon: Eye, tint: "#ec4899" },
  ];

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
            <TrendingUp className="mr-1.5 inline size-4" />
            Dashboard
          </p>
          <h1 className="mt-2 font-display text-4xl font-bold tracking-tight">
            Overview
          </h1>
        </div>
        <div className="flex gap-2">
          <Link
            href="/dashboard/tutorials/new"
            className="flex items-center gap-2 rounded-full bg-forest px-5 py-2.5 text-sm font-bold text-white transition-colors hover:bg-ink"
          >
            <Plus className="size-4" /> New tutorial
          </Link>
          <Link
            href="/dashboard/courses/new"
            className="flex items-center gap-2 rounded-full bg-brand px-5 py-2.5 text-sm font-bold text-forest transition-transform hover:scale-105"
          >
            <Plus className="size-4" /> New course
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        {cards.map((c) => (
          <div
            key={c.label}
            className="rounded-2xl border border-ink/10 bg-white p-5 shadow-sm"
          >
            <span
              className="grid size-10 place-items-center rounded-xl"
              style={{ backgroundColor: `${c.tint}1c`, color: c.tint }}
            >
              <c.icon className="size-5" />
            </span>
            <p className="mt-4 font-display text-3xl font-bold tracking-tight">
              {c.value}
            </p>
            <p className="text-xs font-bold uppercase tracking-widest text-ink/40">
              {c.label}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-2">
        {/* Recent tutorials */}
        <section className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold tracking-tight">
              Tutorials
            </h2>
            <Link
              href="/dashboard/tutorials"
              className="flex items-center gap-1 text-xs font-bold text-brand-deep hover:underline"
            >
              Manage all <ArrowUpRight className="size-3.5" />
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-ink/5">
            {recentTutorials.length === 0 && (
              <li className="py-8 text-center text-sm text-ink/40">
                No tutorials yet.{" "}
                <Link
                  href="/dashboard/tutorials/new"
                  className="font-bold text-brand-deep"
                >
                  Create the first one
                </Link>
              </li>
            )}
            {recentTutorials.map((t, i) => {
              const Icon = getIcon(t.icon);
              return (
                <li key={t.id} className="flex items-center gap-3 py-3">
                  <span
                    className="grid size-10 shrink-0 place-items-center rounded-xl"
                    style={{ backgroundColor: `${t.color}1c`, color: t.color }}
                  >
                    <Icon className="size-5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold">
                      {t.title}
                    </span>
                    <span className="text-xs text-ink/40">
                      {tutorialLessons[i]} lessons ·{" "}
                      {t.published ? (
                        <span className="font-bold text-brand-deep">Published</span>
                      ) : (
                        <span className="font-bold text-amber-600">Draft</span>
                      )}
                    </span>
                  </span>
                  <Link
                    href={`/dashboard/tutorials/${t.id}`}
                    className="grid size-8 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-forest hover:text-white"
                  >
                    <Pencil className="size-3.5" />
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Recent courses */}
        <section className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold tracking-tight">
              Courses
            </h2>
            <Link
              href="/dashboard/courses"
              className="flex items-center gap-1 text-xs font-bold text-brand-deep hover:underline"
            >
              Manage all <ArrowUpRight className="size-3.5" />
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-ink/5">
            {recentCourses.length === 0 && (
              <li className="py-8 text-center text-sm text-ink/40">
                No courses yet.{" "}
                <Link
                  href="/dashboard/courses/new"
                  className="font-bold text-brand-deep"
                >
                  Create the first one
                </Link>
              </li>
            )}
            {recentCourses.map((c, i) => {
              const Icon = getIcon(c.icon);
              return (
                <li key={c.id} className="flex items-center gap-3 py-3">
                  <span
                    className="grid size-10 shrink-0 place-items-center rounded-xl"
                    style={{ backgroundColor: `${c.color}1c`, color: c.color }}
                  >
                    <Icon className="size-5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold">
                      {c.title}
                    </span>
                    <span className="text-xs text-ink/40">
                      {courseLessons[i]} lessons ·{" "}
                      {c.published ? (
                        <span className="font-bold text-brand-deep">Published</span>
                      ) : (
                        <span className="font-bold text-amber-600">Draft</span>
                      )}
                    </span>
                  </span>
                  <Link
                    href={`/dashboard/courses/${c.id}`}
                    className="grid size-8 place-items-center rounded-full border border-ink/10 text-ink-soft transition-colors hover:bg-forest hover:text-white"
                  >
                    <Pencil className="size-3.5" />
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </div>
  );
}
