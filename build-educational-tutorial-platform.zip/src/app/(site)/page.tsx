import Link from "next/link";
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  Clock3,
  Compass,
  Flame,
  GraduationCap,
  Layers,
  Rocket,
  Signal,
  Sparkles,
} from "lucide-react";
import {
  getPublishedCourses,
  getPublishedTutorials,
  getTutorialSectionCounts,
} from "@/lib/queries";
import { getIcon } from "@/lib/icons";
import HeroSearch from "@/components/home/hero-search";
import TryItEditor from "@/components/try-it-editor";

export const dynamic = "force-dynamic";

const HERO_DEMO = `<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: system-ui, sans-serif;
      background: #0a1f14;
      color: #eafff5;
      text-align: center;
      padding-top: 56px;
    }
    h1 { color: #04aa6d; font-size: 2.4rem; }
    button {
      background: #04aa6d;
      color: #062117;
      border: none;
      padding: 12px 28px;
      border-radius: 999px;
      font-size: 1rem;
      font-weight: 700;
      cursor: pointer;
      transition: transform 0.2s;
    }
    button:hover { transform: scale(1.08); }
  </style>
</head>
<body>

  <h1>Hello, developer!</h1>
  <p>Edit this code and watch the result change live.</p>
  <button onclick="this.textContent='It works!'">
    Click me
  </button>

</body>
</html>`;

export default async function HomePage() {
  const [tutorials, courses, counts] = await Promise.all([
    getPublishedTutorials(),
    getPublishedCourses(),
    getTutorialSectionCounts(),
  ]);
  const countMap = new Map(counts.map((c) => [c.tutorialId, c.total]));

  const marqueeItems = [
    ...tutorials.map((t) => t.title),
    "Responsive Design",
    "Web APIs",
    "Accessibility",
    "TypeScript",
    "Career Paths",
  ];

  return (
    <>
      {/* ============ HERO ============ */}
      <section className="relative overflow-hidden bg-forest text-white">
        <div className="hero-glow absolute inset-x-0 top-0 h-full" />
        <div className="hero-grid absolute inset-0" />
        <div className="relative mx-auto grid max-w-7xl gap-14 px-4 pb-20 pt-16 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:pb-28 lg:pt-24">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-brand">
              <Sparkles className="size-3.5" />
              The world&apos;s largest dev learning site
            </div>
            <h1 className="mt-6 font-display text-6xl font-bold leading-[0.95] tracking-tight sm:text-7xl">
              Learn to
              <span className="block text-brand">Code</span>
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-white/65">
              Free interactive tutorials, live code examples and structured
              courses. Write, run and experiment — right in your browser.
            </p>

            <div className="mt-9">
              <HeroSearch />
            </div>

            <div className="mt-9 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-white/55">
              <span className="flex items-center gap-2">
                <BookOpen className="size-4 text-brand" />
                {tutorials.length}+ tutorials
              </span>
              <span className="flex items-center gap-2">
                <GraduationCap className="size-4 text-brand" />
                {courses.length} guided courses
              </span>
              <span className="flex items-center gap-2">
                <Flame className="size-4 text-brand" />
                100% free
              </span>
            </div>
          </div>

          <div className="animate-float-slow">
            <TryItEditor initialCode={HERO_DEMO} height={430} />
            <p className="mt-4 text-center font-mono text-xs text-white/35">
              live editor — go ahead, break things
            </p>
          </div>
        </div>
      </section>

      {/* ============ MARQUEE ============ */}
      <div className="overflow-hidden border-y border-ink/10 bg-brand py-3.5">
        <div className="flex w-max animate-marquee gap-10">
          {[...marqueeItems, ...marqueeItems].map((item, i) => (
            <span
              key={i}
              className="flex items-center gap-10 whitespace-nowrap font-display text-sm font-bold uppercase tracking-[0.2em] text-forest"
            >
              {item}
              <span className="size-1.5 rounded-full bg-forest/50" />
            </span>
          ))}
        </div>
      </div>

      {/* ============ TUTORIALS ============ */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
              01 — Tutorials
            </p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Pick a language.
              <span className="text-ink/35"> Start today.</span>
            </h2>
          </div>
          <Link
            href="/tutorials"
            className="group flex items-center gap-2 rounded-full border-2 border-ink px-5 py-2.5 text-sm font-bold transition-colors hover:bg-ink hover:text-white"
          >
            All tutorials
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {tutorials.map((t) => {
            const Icon = getIcon(t.icon);
            return (
              <Link
                key={t.id}
                href={`/tutorials/${t.slug}`}
                className="card-lift group relative overflow-hidden rounded-3xl border border-ink/10 bg-white p-7 shadow-sm hover:shadow-2xl hover:shadow-ink/10"
              >
                <div
                  className="absolute inset-x-0 top-0 h-1.5"
                  style={{ backgroundColor: t.color }}
                />
                <div className="flex items-start justify-between">
                  <span
                    className="grid size-13 place-items-center rounded-2xl"
                    style={{ backgroundColor: `${t.color}1c`, color: t.color }}
                  >
                    <Icon className="size-6.5" />
                  </span>
                  <span className="rounded-full bg-cream px-3 py-1 text-xs font-bold text-ink-soft">
                    {countMap.get(t.id) ?? 0} lessons
                  </span>
                </div>
                <h3 className="mt-6 font-display text-2xl font-bold tracking-tight">
                  {t.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-soft">
                  {t.tagline || t.description}
                </p>
                <span
                  className="mt-6 inline-flex items-center gap-2 text-sm font-bold"
                  style={{ color: t.color }}
                >
                  Learn {t.title}
                  <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* ============ WHERE TO BEGIN ============ */}
      <section className="stripe-bg bg-forest py-20 text-white lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="max-w-2xl">
            <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand">
              02 — Roadmap
            </p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Not sure where to begin?
            </h2>
            <p className="mt-4 text-lg text-white/60">
              Follow the path thousands of developers started with. Three
              steps, zero confusion.
            </p>
          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {[
              {
                icon: Compass,
                step: "Step 1",
                title: "HTML — the skeleton",
                text: "Structure your first web page with tags, elements and attributes.",
              },
              {
                icon: Layers,
                step: "Step 2",
                title: "CSS — the style",
                text: "Colors, layouts, flexbox and grid. Make it beautiful on every screen.",
              },
              {
                icon: Rocket,
                step: "Step 3",
                title: "JavaScript — the brain",
                text: "Interactivity, logic and the DOM. Turn pages into real apps.",
              },
            ].map((s) => (
              <div
                key={s.step}
                className="group rounded-3xl border border-white/10 bg-forest-soft p-8 transition-colors duration-300 hover:border-brand/50"
              >
                <span className="grid size-12 place-items-center rounded-2xl bg-brand/15 text-brand transition-colors group-hover:bg-brand group-hover:text-forest">
                  <s.icon className="size-6" />
                </span>
                <p className="mt-6 font-mono text-xs font-bold uppercase tracking-[0.25em] text-white/40">
                  {s.step}
                </p>
                <h3 className="mt-2 font-display text-xl font-bold">
                  {s.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-white/55">
                  {s.text}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-10">
            <Link
              href="/tutorials"
              className="inline-flex items-center gap-2 rounded-full bg-brand px-7 py-3.5 font-bold text-forest transition-transform hover:scale-105"
            >
              Start the roadmap
              <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ============ COURSES ============ */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
              03 — Courses
            </p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Go deeper with
              <span className="text-ink/35"> guided courses</span>
            </h2>
          </div>
          <Link
            href="/courses"
            className="group flex items-center gap-2 rounded-full border-2 border-ink px-5 py-2.5 text-sm font-bold transition-colors hover:bg-ink hover:text-white"
          >
            All courses
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {courses.slice(0, 4).map((c) => {
            const Icon = getIcon(c.icon);
            return (
              <Link
                key={c.id}
                href={`/courses/${c.slug}`}
                className="card-lift group overflow-hidden rounded-3xl border border-ink/10 bg-white shadow-sm hover:shadow-2xl hover:shadow-ink/10"
              >
                <div
                  className="relative flex h-40 items-end overflow-hidden p-6"
                  style={{
                    background: `linear-gradient(135deg, ${c.color}, ${c.color}88)`,
                  }}
                >
                  <Icon className="absolute -right-5 -top-5 size-36 text-white/20 transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110" />
                  <div className="relative flex w-full items-center justify-between">
                    <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-bold uppercase tracking-widest text-white backdrop-blur-sm">
                      {c.level}
                    </span>
                    <span className="rounded-full bg-white px-3.5 py-1 text-xs font-bold text-ink">
                      {c.price}
                    </span>
                  </div>
                </div>
                <div className="p-7">
                  <h3 className="font-display text-2xl font-bold tracking-tight">
                    {c.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-soft">
                    {c.description}
                  </p>
                  <div className="mt-5 flex flex-wrap items-center gap-5 text-xs font-semibold text-ink-soft">
                    <span className="flex items-center gap-1.5">
                      <Clock3 className="size-4 text-brand" />
                      {c.duration}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Signal className="size-4 text-brand" />
                      {c.level}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <BarChart3 className="size-4 text-brand" />
                      Certificate included
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* ============ CREATOR CTA ============ */}
      <section className="mx-auto max-w-7xl px-4 pb-24 sm:px-6">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-ink px-8 py-16 text-center text-white sm:px-16">
          <div className="hero-glow absolute inset-0" />
          <div className="relative">
            <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand">
              For creators &amp; teachers
            </p>
            <h2 className="mx-auto mt-4 max-w-2xl font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Have knowledge to share? Publish it.
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-white/60">
              Use the dashboard to upload your own tutorials and courses —
              lessons, code examples and everything in between.
            </p>
            <div className="mt-9 flex flex-wrap justify-center gap-4">
              <Link
                href="/dashboard/tutorials/new"
                className="rounded-full bg-brand px-7 py-3.5 font-bold text-forest transition-transform hover:scale-105"
              >
                Upload a tutorial
              </Link>
              <Link
                href="/dashboard/courses/new"
                className="rounded-full border border-white/25 px-7 py-3.5 font-bold text-white transition-colors hover:bg-white/10"
              >
                Create a course
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
