import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  Award,
  BookOpen,
  ChevronRight,
  Clock3,
  Infinity as InfinityIcon,
  MonitorPlay,
  PlayCircle,
  Signal,
} from "lucide-react";
import { getCourseBySlug, getLessons } from "@/lib/queries";
import { getIcon } from "@/lib/icons";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const course = await getCourseBySlug(slug);
  if (!course) return { title: "Course not found" };
  return { title: course.title, description: course.description };
}

export default async function CourseDetailPage({ params }: Props) {
  const { slug } = await params;
  const course = await getCourseBySlug(slug);
  if (!course || !course.published) notFound();

  const lessons = await getLessons(course.id);
  const Icon = getIcon(course.icon);

  return (
    <div>
      {/* Hero */}
      <section
        className="relative overflow-hidden text-white"
        style={{
          background: `linear-gradient(120deg, #0a1f14 25%, ${course.color}40 100%)`,
        }}
      >
        <div className="hero-grid absolute inset-0" />
        <Icon className="absolute -right-8 top-1/2 hidden size-72 -translate-y-1/2 text-white/10 lg:block" />
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
          <nav className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-white/50">
            <Link href="/courses" className="hover:text-white">
              Courses
            </Link>
            <ChevronRight className="size-3.5" />
            <span style={{ color: course.color }}>{course.title}</span>
          </nav>
          <h1 className="mt-6 max-w-3xl font-display text-4xl font-bold leading-tight tracking-tight sm:text-6xl">
            {course.title}
          </h1>
          <p className="mt-5 max-w-2xl text-lg leading-relaxed text-white/65">
            {course.description}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-6 text-sm font-semibold text-white/70">
            <span className="flex items-center gap-2">
              <Signal className="size-4.5" style={{ color: course.color }} />
              {course.level}
            </span>
            <span className="flex items-center gap-2">
              <Clock3 className="size-4.5" style={{ color: course.color }} />
              {course.duration}
            </span>
            <span className="flex items-center gap-2">
              <BookOpen className="size-4.5" style={{ color: course.color }} />
              {lessons.length} lessons
            </span>
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1fr_340px]">
        {/* Lessons */}
        <div>
          <h2 className="font-display text-3xl font-bold tracking-tight">
            Course content
          </h2>
          {lessons.length === 0 ? (
            <div className="mt-8 rounded-3xl border border-dashed border-ink/20 py-16 text-center text-ink-soft">
              Lessons are on the way.
            </div>
          ) : (
            <ol className="mt-8 overflow-hidden rounded-3xl border border-ink/10 bg-white shadow-sm">
              {lessons.map((l, i) => (
                <li
                  key={l.id}
                  className="group flex items-start gap-4 border-b border-ink/5 px-6 py-5 transition-colors last:border-0 hover:bg-cream/60 sm:px-7"
                >
                  <span
                    className="mt-0.5 grid size-10 shrink-0 place-items-center rounded-full"
                    style={{
                      backgroundColor: `${course.color}1a`,
                      color: course.color,
                    }}
                  >
                    <PlayCircle className="size-5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-lg font-bold tracking-tight">
                      {l.title}
                    </span>
                    {l.content && (
                      <span
                        className="lesson-content mt-1.5 line-clamp-2 text-sm"
                        dangerouslySetInnerHTML={{ __html: l.content }}
                      />
                    )}
                  </span>
                  <span className="mt-1 flex shrink-0 items-center gap-1.5 text-xs font-bold text-ink/40">
                    <Clock3 className="size-3.5" />
                    {l.duration}
                  </span>
                </li>
              ))}
            </ol>
          )}
        </div>

        {/* Enroll card */}
        <aside>
          <div className="sticky top-24 rounded-3xl border border-ink/10 bg-white p-7 shadow-xl shadow-ink/5">
            <div
              className="grid h-36 place-items-center rounded-2xl"
              style={{
                background: `linear-gradient(135deg, ${course.color}, ${course.color}88)`,
              }}
            >
              <span className="grid size-16 place-items-center rounded-full bg-white/25 backdrop-blur-sm">
                <PlayCircle className="size-8 text-white" />
              </span>
            </div>
            <p className="mt-6 font-display text-3xl font-bold tracking-tight">
              {course.price}
            </p>
            <a
              href="#lessons"
              className="mt-4 block rounded-full py-3.5 text-center font-bold text-forest transition-transform hover:scale-[1.02]"
              style={{ backgroundColor: course.color }}
            >
              Start learning now
            </a>
            <p className="mt-3 text-center text-xs font-semibold text-ink/40">
              Free access · no card required
            </p>
            <ul className="mt-6 grid gap-3 border-t border-ink/10 pt-6 text-sm font-medium text-ink-soft">
              <li className="flex items-center gap-2.5">
                <MonitorPlay className="size-4.5 text-brand" />
                {course.duration} of content
              </li>
              <li className="flex items-center gap-2.5">
                <BookOpen className="size-4.5 text-brand" />
                {lessons.length} hands-on lessons
              </li>
              <li className="flex items-center gap-2.5">
                <InfinityIcon className="size-4.5 text-brand" />
                Lifetime access
              </li>
              <li className="flex items-center gap-2.5">
                <Award className="size-4.5 text-brand" />
                Certificate of completion
              </li>
            </ul>
          </div>
        </aside>
      </section>
    </div>
  );
}
