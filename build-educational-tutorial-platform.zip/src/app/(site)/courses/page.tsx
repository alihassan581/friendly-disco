import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Clock3, Signal } from "lucide-react";
import { getLessons, getPublishedCourses } from "@/lib/queries";
import { getIcon } from "@/lib/icons";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Courses",
  description: "Guided, structured courses to take you from zero to job-ready.",
};

export default async function CoursesPage() {
  const courses = await getPublishedCourses();
  const lessonCounts = await Promise.all(
    courses.map(async (c) => (await getLessons(c.id)).length)
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-20">
      <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
        Guided learning
      </p>
      <h1 className="mt-3 font-display text-5xl font-bold tracking-tight">
        Courses
      </h1>
      <p className="mt-4 max-w-xl text-lg text-ink-soft">
        Structured paths with hands-on lessons, code-along projects and a
        completion certificate at the finish line.
      </p>

      {courses.length === 0 ? (
        <div className="mt-16 rounded-3xl border border-dashed border-ink/20 py-20 text-center text-ink-soft">
          No courses published yet — check back soon, or create one from the
          dashboard.
        </div>
      ) : (
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {courses.map((c, i) => {
            const Icon = getIcon(c.icon);
            return (
              <Link
                key={c.id}
                href={`/courses/${c.slug}`}
                className="card-lift group overflow-hidden rounded-3xl border border-ink/10 bg-white shadow-sm hover:shadow-2xl hover:shadow-ink/10"
              >
                <div
                  className="relative flex h-44 items-end overflow-hidden p-6"
                  style={{
                    background: `linear-gradient(135deg, ${c.color}, ${c.color}77)`,
                  }}
                >
                  <Icon className="absolute -right-5 -top-5 size-40 text-white/20 transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110" />
                  <div className="relative flex w-full items-center justify-between">
                    <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-bold uppercase tracking-widest text-white backdrop-blur-sm">
                      {c.level}
                    </span>
                    <span className="rounded-full bg-white px-3.5 py-1 text-xs font-bold text-ink">
                      {c.price}
                    </span>
                  </div>
                </div>
                <div className="p-7">
                  <h2 className="font-display text-2xl font-bold tracking-tight">
                    {c.title}
                  </h2>
                  <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-soft">
                    {c.description}
                  </p>
                  <div className="mt-5 flex flex-wrap items-center gap-5 text-xs font-semibold text-ink-soft">
                    <span className="flex items-center gap-1.5">
                      <Clock3 className="size-4 text-brand" />
                      {c.duration}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Signal className="size-4 text-brand" />
                      {c.level}
                    </span>
                    <span className="rounded-full bg-cream px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider">
                      {lessonCounts[i]} lessons
                    </span>
                    <span className="ml-auto flex items-center gap-1.5 font-bold text-brand-deep">
                      View course
                      <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
