import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  ChevronRight,
  Clock3,
  ListTree,
} from "lucide-react";
import { getSections, getTutorialBySlug } from "@/lib/queries";
import TutorialSidebar from "@/components/tutorial-sidebar";
import CodeBlock from "@/components/code-block";
import { estimateReadMinutes } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string; section: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug, section } = await params;
  const tutorial = await getTutorialBySlug(slug);
  if (!tutorial) return { title: "Lesson not found" };
  const sections = await getSections(tutorial.id);
  const current = sections.find((s) => s.slug === section);
  if (!current) return { title: "Lesson not found" };
  return {
    title: `${current.title} — ${tutorial.title} Tutorial`,
    description: tutorial.tagline || tutorial.description,
  };
}

export default async function LessonPage({ params }: Props) {
  const { slug, section } = await params;
  const tutorial = await getTutorialBySlug(slug);
  if (!tutorial || !tutorial.published) notFound();

  const sections = await getSections(tutorial.id);
  const index = sections.findIndex((s) => s.slug === section);
  if (index === -1) notFound();

  const current = sections[index];
  const prev = index > 0 ? sections[index - 1] : null;
  const next = index < sections.length - 1 ? sections[index + 1] : null;
  const nonRunnable = new Set(["sql", "python", "react"]).has(tutorial.slug);
  const codeLang = tutorial.slug === "sql" ? "sql" : nonRunnable ? "text" : "html";

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6">
      <div className="grid lg:grid-cols-[280px_minmax(0,1fr)] lg:gap-12">
        {/* Sidebar — desktop */}
        <aside className="sticky top-16 hidden h-[calc(100vh-4rem)] py-8 lg:block">
          <TutorialSidebar
            tutorial={tutorial}
            sections={sections}
            activeId={current.id}
          />
        </aside>

        <div className="min-w-0 py-8 lg:py-12">
          {/* Mobile chapter menu */}
          <details className="group mb-8 rounded-2xl border border-ink/10 bg-white lg:hidden">
            <summary className="flex cursor-pointer list-none items-center gap-3 px-5 py-4 text-sm font-bold">
              <ListTree className="size-4.5" style={{ color: tutorial.color }} />
              Tutorial menu
              <ChevronRight className="ml-auto size-4 transition-transform group-open:rotate-90" />
            </summary>
            <div className="max-h-80 overflow-y-auto border-t border-ink/5 p-3">
              <TutorialSidebar
                tutorial={tutorial}
                sections={sections}
                activeId={current.id}
              />
            </div>
          </details>

          {/* Breadcrumb + prev/next */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <nav className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-ink/40">
              <Link href="/tutorials" className="hover:text-ink">
                Tutorials
              </Link>
              <ChevronRight className="size-3.5" />
              <Link
                href={`/tutorials/${tutorial.slug}`}
                className="hover:text-ink"
              >
                {tutorial.title}
              </Link>
              <ChevronRight className="size-3.5" />
              <span style={{ color: tutorial.color }}>{current.title}</span>
            </nav>
            <div className="flex gap-2">
              {prev ? (
                <Link
                  href={`/tutorials/${tutorial.slug}/${prev.slug}`}
                  className="flex items-center gap-1.5 rounded-full border border-ink/15 px-4 py-2 text-xs font-bold transition-colors hover:bg-ink hover:text-white"
                >
                  <ArrowLeft className="size-3.5" /> Prev
                </Link>
              ) : (
                <span />
              )}
              {next && (
                <Link
                  href={`/tutorials/${tutorial.slug}/${next.slug}`}
                  className="flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold text-white transition-transform hover:scale-105"
                  style={{ backgroundColor: tutorial.color }}
                >
                  Next <ArrowRight className="size-3.5" />
                </Link>
              )}
            </div>
          </div>

          {/* Content */}
          <article className="mt-10">
            <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
              {current.title}
            </h1>
            <p className="mt-4 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-ink/40">
              <Clock3 className="size-4" style={{ color: tutorial.color }} />
              {estimateReadMinutes(current.content)} min read · Lesson{" "}
              {index + 1} of {sections.length}
            </p>

            <div
              className="lesson-content mt-8"
              dangerouslySetInnerHTML={{ __html: current.content }}
            />

            {current.codeExample.trim() && (
              <CodeBlock
                code={current.codeExample}
                lang={codeLang}
                runnableSectionId={nonRunnable ? null : current.id}
              />
            )}
          </article>

          {/* Bottom prev/next */}
          <div className="mt-14 grid gap-3 sm:grid-cols-2">
            {prev ? (
              <Link
                href={`/tutorials/${tutorial.slug}/${prev.slug}`}
                className="group rounded-2xl border border-ink/10 bg-white p-5 transition-colors hover:border-ink/30"
              >
                <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-ink/40">
                  <ArrowLeft className="size-3.5" /> Previous
                </span>
                <span className="mt-1.5 block font-display text-lg font-bold tracking-tight">
                  {prev.title}
                </span>
              </Link>
            ) : (
              <span />
            )}
            {next ? (
              <Link
                href={`/tutorials/${tutorial.slug}/${next.slug}`}
                className="group rounded-2xl border border-ink/10 bg-white p-5 text-right transition-colors hover:border-ink/30"
              >
                <span
                  className="flex items-center justify-end gap-1.5 text-xs font-bold uppercase tracking-widest"
                  style={{ color: tutorial.color }}
                >
                  Next lesson <ArrowRight className="size-3.5" />
                </span>
                <span className="mt-1.5 block font-display text-lg font-bold tracking-tight">
                  {next.title}
                </span>
              </Link>
            ) : (
              <span />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
