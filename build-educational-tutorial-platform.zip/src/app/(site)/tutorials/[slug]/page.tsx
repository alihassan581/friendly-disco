import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowRight,
  BookOpen,
  ChevronRight,
  Clock3,
  Play,
  Trophy,
} from "lucide-react";
import { getSections, getTutorialBySlug } from "@/lib/queries";
import { getIcon } from "@/lib/icons";
import { estimateReadMinutes } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const tutorial = await getTutorialBySlug(slug);
  if (!tutorial) return { title: "Tutorial not found" };
  return {
    title: `${tutorial.title} Tutorial`,
    description: tutorial.description || tutorial.tagline,
  };
}

export default async function TutorialLandingPage({ params }: Props) {
  const { slug } = await params;
  const tutorial = await getTutorialBySlug(slug);
  if (!tutorial || !tutorial.published) notFound();

  const sections = await getSections(tutorial.id);
  const first = sections[0];
  const Icon = getIcon(tutorial.icon);
  const totalMinutes = sections.reduce(
    (acc, s) => acc + estimateReadMinutes(s.content),
    4
  );

  return (
    <div>
      {/* Hero band */}
      <section
        className="relative overflow-hidden text-white"
        style={{
          background: `linear-gradient(120deg, #0a1f14 30%, ${tutorial.color}33 100%)`,
        }}
      >
        <div className="hero-grid absolute inset-0" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_320px] lg:items-center lg:py-20">
          <div>
            <nav className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-white/50">
              <Link href="/tutorials" className="hover:text-white">
                Tutorials
              </Link>
              <ChevronRight className="size-3.5" />
              <span style={{ color: tutorial.color }}>{tutorial.title}</span>
            </nav>
            <div className="mt-6 flex items-center gap-5">
              <span
                className="grid size-16 place-items-center rounded-2xl shadow-lg sm:size-20"
                style={{ backgroundColor: tutorial.color }}
              >
                <Icon className="size-8 sm:size-10" />
              </span>
              <div>
                <h1 className="font-display text-4xl font-bold tracking-tight sm:text-6xl">
                  {tutorial.title}
                  <span className="text-white/40"> Tutorial</span>
                </h1>
              </div>
            </div>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/65">
              {tutorial.description || tutorial.tagline}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-6 text-sm font-semibold text-white/70">
              <span className="flex items-center gap-2">
                <BookOpen className="size-4.5" style={{ color: tutorial.color }} />
                {sections.length} lessons
              </span>
              <span className="flex items-center gap-2">
                <Clock3 className="size-4.5" style={{ color: tutorial.color }} />
                ~{totalMinutes} min read
              </span>
              <span className="flex items-center gap-2">
                <Trophy className="size-4.5" style={{ color: tutorial.color }} />
                Free forever
              </span>
            </div>
            {first && (
              <Link
                href={`/tutorials/${tutorial.slug}/${first.slug}`}
                className="mt-10 inline-flex items-center gap-2 rounded-full px-8 py-4 font-display text-base font-bold text-forest transition-transform hover:scale-105"
                style={{ backgroundColor: tutorial.color }}
              >
                Start learning {tutorial.title}
                <ArrowRight className="size-5" />
              </Link>
            )}
          </div>

          {first && (
            <div className="hidden rounded-3xl border border-white/10 bg-forest/60 p-6 backdrop-blur-sm lg:block">
              <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-white/40">
                Practice as you read
              </p>
              <p className="mt-3 text-sm leading-relaxed text-white/65">
                Every example in this tutorial opens in our live editor — tweak
                the code and see what happens.
              </p>
              <Link
                href={`/tryit/${first.id}`}
                className="mt-5 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold text-forest transition-transform hover:scale-[1.02]"
                style={{ backgroundColor: tutorial.color }}
              >
                <Play className="size-4" />
                Open the playground
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Curriculum */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
              Curriculum
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">
              What you&apos;ll learn
            </h2>
          </div>
          <p className="hidden text-sm font-semibold text-ink/40 sm:block">
            {sections.length} chapters
          </p>
        </div>

        {sections.length === 0 ? (
          <div className="mt-10 rounded-3xl border border-dashed border-ink/20 py-16 text-center text-ink-soft">
            Lessons for this tutorial are coming soon.
          </div>
        ) : (
          <ol className="mt-10 overflow-hidden rounded-3xl border border-ink/10 bg-white shadow-sm">
            {sections.map((s, i) => (
              <li key={s.id}>
                <Link
                  href={`/tutorials/${tutorial.slug}/${s.slug}`}
                  className="group flex items-center gap-5 border-b border-ink/5 px-6 py-5 transition-colors last:border-0 hover:bg-cream/60 sm:px-8"
                >
                  <span
                    className="grid size-10 shrink-0 place-items-center rounded-full font-mono text-sm font-bold transition-colors"
                    style={{
                      backgroundColor: `${tutorial.color}1a`,
                      color: tutorial.color,
                    }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-display text-lg font-bold tracking-tight">
                      {s.title}
                    </span>
                    <span className="text-xs font-semibold text-ink/40">
                      {estimateReadMinutes(s.content)} min · lesson {i + 1} of{" "}
                      {sections.length}
                    </span>
                  </span>
                  <ArrowRight
                    className="size-5 shrink-0 transition-transform duration-300 group-hover:translate-x-1.5"
                    style={{ color: tutorial.color }}
                  />
                </Link>
              </li>
            ))}
          </ol>
        )}
      </section>
    </div>
  );
}
