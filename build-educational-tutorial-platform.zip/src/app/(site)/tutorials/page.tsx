import type { Metadata } from "next";
import { getPublishedTutorials, getTutorialSectionCounts } from "@/lib/queries";
import TutorialsIndex from "@/components/tutorials-index";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "All Tutorials",
  description: "Browse every free coding tutorial on Codecampus.",
};

export default async function TutorialsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const [tutorials, counts] = await Promise.all([
    getPublishedTutorials(),
    getTutorialSectionCounts(),
  ]);
  const countMap = new Map(counts.map((c) => [c.tutorialId, c.total]));

  return (
    <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-20">
      <p className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-brand-deep">
        Tutorial index
      </p>
      <h1 className="mt-3 font-display text-5xl font-bold tracking-tight">
        All Tutorials
      </h1>
      <p className="mt-4 max-w-xl text-lg text-ink-soft">
        Every tutorial is free, interactive and packed with live code examples
        you can run instantly.
      </p>

      <div className="mt-10">
        <TutorialsIndex
          initialQuery={q ?? ""}
          tutorials={tutorials.map((t) => ({
            id: t.id,
            slug: t.slug,
            title: t.title,
            tagline: t.tagline,
            category: t.category,
            color: t.color,
            icon: t.icon,
            lessons: countMap.get(t.id) ?? 0,
          }))}
        />
      </div>
    </div>
  );
}
